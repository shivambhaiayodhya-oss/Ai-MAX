package com.example.model

enum class ExecutionState(val label: String, val hindiLabel: String) {
    DISCONNECTED("DISCONNECTED", "डिस्कनेक्टेड"),
    CONNECTING("CONNECTING", "कनेक्ट हो रहा है..."),
    LISTENING("LISTENING", "सुन रही हूँ..."),
    THINKING("THINKING", "सोच रही हूँ..."),
    SPEAKING("SPEAKING", "बोल रही हूँ..."),
    EXECUTING("EXECUTING", "एक्शन ले रही हूँ..."),
    ERROR("ERROR", "कोई समस्या आई")
}

data class ToolResult(
    val success: Boolean,
    val hindiResponse: String,
    val technicalDetail: String? = null,
    val actionType: String? = null
)

data class PermissionStatus(
    val hasAudioRecord: Boolean = false,
    val hasCallPhone: Boolean = false,
    val hasReadContacts: Boolean = false,
    val hasSendSms: Boolean = false,
    val isAccessibilityEnabled: Boolean = false
)
