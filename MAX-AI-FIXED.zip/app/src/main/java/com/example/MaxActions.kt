package com.max.ai

/**
 * Canonical action names understood by the Smart Action layer.
 * Existing ToolRegistry/ToolExecutor implementations can map their current
 * tool names into these actions.
 */
object MaxActions {
    const val OPEN_APP = "OPEN_APP"
    const val BACK = "BACK"
    const val HOME = "HOME"
    const val RECENTS = "RECENTS"
    const val CLICK_TEXT = "CLICK_TEXT"
    const val CLICK_DESCRIPTION = "CLICK_DESCRIPTION"
    const val CLICK_COORDINATE = "CLICK_COORDINATE"
    const val LONG_CLICK = "LONG_CLICK"
    const val TYPE_TEXT = "TYPE_TEXT"
    const val CLEAR_TEXT = "CLEAR_TEXT"
    const val SCROLL = "SCROLL"
    const val SWIPE = "SWIPE"
    const val READ_SCREEN = "READ_SCREEN"
    const val FIND_ELEMENT = "FIND_ELEMENT"
    const val WAIT = "WAIT"
    const val CALL = "CALL"
    const val END_CALL = "END_CALL"
    const val ANSWER_CALL = "ANSWER_CALL"
    const val SET_VOLUME = "SET_VOLUME"
    const val MUTE = "MUTE"
    const val UNMUTE = "UNMUTE"
    const val PLAY = "PLAY"
    const val PAUSE = "PAUSE"
    const val NEXT = "NEXT"
    const val PREVIOUS = "PREVIOUS"
}
