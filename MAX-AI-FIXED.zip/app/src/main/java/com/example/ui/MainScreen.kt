package com.example.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ExecutionState
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSilver
import com.example.ui.theme.CyberSilverMuted
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberYellow
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val state by viewModel.assistantState.collectAsState()
    val audioLevel by viewModel.audioLevel.collectAsState()
    val lastHeard by viewModel.lastHeardText.collectAsState()
    val lastResponse by viewModel.lastResponseText.collectAsState()
    val actionInfo by viewModel.executedActionInfo.collectAsState()
    val permissions by viewModel.permissionStatus.collectAsState()

    var showPermissionsSheet by remember { mutableStateOf(false) }

    // Multi-permission launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshPermissions()
    }

    LaunchedEffect(Unit) {
        viewModel.refreshPermissions()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack),
        containerColor = CyberBlack,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { paddingValues ->
        val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF030712),
                            Color(0xFF0A0F1D),
                            Color(0xFF04060A)
                        )
                    )
                )
        ) {
            // Background Cyber Grid / Ambient Glow
            CyberBackgroundGrid(state = state, audioLevel = audioLevel)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = statusBarPadding + 12.dp,
                        bottom = navBarPadding + 16.dp,
                        start = 20.dp,
                        end = 20.dp
                    )
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Bar with Warrior Brand and System Badges
                TopActionBar(
                    isAccessibilityActive = permissions.isAccessibilityEnabled,
                    onOpenSettings = { showPermissionsSheet = true },
                    onRequestPermissions = {
                        permissionsLauncher.launch(
                            arrayOf(
                                android.Manifest.permission.RECORD_AUDIO,
                                android.Manifest.permission.CALL_PHONE,
                                android.Manifest.permission.READ_CONTACTS,
                                android.Manifest.permission.SEND_SMS
                            )
                        )
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // State Badge Indicator
                StateBadge(state = state, actionInfo = actionInfo)

                Spacer(modifier = Modifier.height(24.dp))

                // Central Voice Button & Reactive Warrior Visualizer
                Box(
                    modifier = Modifier.size(280.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CentralVoiceVisualizer(
                        state = state,
                        audioLevel = audioLevel,
                        onClick = { viewModel.onVoiceOrbClick() }
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Live Voice & Conversation Feedback Panel
                ConversationFeedbackCard(
                    state = state,
                    lastHeard = lastHeard,
                    lastResponse = lastResponse
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Quick Action Voice Prompts
                QuickActionsRow(
                    onSelectCommand = { cmd ->
                        viewModel.processUserInput(cmd)
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Wake word hint footer
                Text(
                    text = "बोलो \"MAX\" या टैप करो • Hindi-First Real Voice Assistant",
                    color = CyberSilverMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center
                )
            }

            // Permissions Bottom Sheet
            if (showPermissionsSheet) {
                PermissionsSheet(
                    permissions = permissions,
                    onDismiss = { showPermissionsSheet = false },
                    onRequestMic = {
                        permissionsLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                    },
                    onRequestCall = {
                        permissionsLauncher.launch(arrayOf(android.Manifest.permission.CALL_PHONE))
                    },
                    onRequestContacts = {
                        permissionsLauncher.launch(arrayOf(android.Manifest.permission.READ_CONTACTS))
                    },
                    onRequestSms = {
                        permissionsLauncher.launch(arrayOf(android.Manifest.permission.SEND_SMS))
                    },
                    onOpenAccessibilitySettings = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun TopActionBar(
    isAccessibilityActive: Boolean,
    onOpenSettings: () -> Unit,
    onRequestPermissions: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title & Futuristic Badge
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_warrior_emblem),
                    contentDescription = "MAX Emblem",
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = "MAX AI",
                    color = CyberSilver,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "HINDI VOICE CORE",
                    color = CyberCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.5.sp
                )
            }
        }

        // Action Status Badges
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Accessibility Service status pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isAccessibilityActive) CyberGreen.copy(alpha = 0.15f)
                        else CyberYellow.copy(alpha = 0.15f)
                    )
                    .border(
                        1.dp,
                        if (isAccessibilityActive) CyberGreen.copy(alpha = 0.4f)
                        else CyberYellow.copy(alpha = 0.4f),
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { onOpenSettings() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("accessibility_pill")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isAccessibilityActive) CyberGreen else CyberYellow)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isAccessibilityActive) "ACCESSIBILITY ON" else "SETUP SERVICE",
                        color = if (isAccessibilityActive) CyberGreen else CyberYellow,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, CircleShape)
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Permissions",
                    tint = CyberSilver,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun StateBadge(state: ExecutionState, actionInfo: String?) {
    val (badgeColor, icon, text) = when (state) {
        ExecutionState.DISCONNECTED -> Triple(CyberSilverMuted, "○", "STANDBY • WAITING FOR 'MAX'")
        ExecutionState.CONNECTING -> Triple(CyberBlue, "◐", "CONNECTING LIVE...")
        ExecutionState.LISTENING -> Triple(CyberCyan, "●", "LISTENING • बोलिए Boss")
        ExecutionState.THINKING -> Triple(CyberPurple, "◆", "PROCESSING COMMAND...")
        ExecutionState.SPEAKING -> Triple(CyberGreen, "♫", "SPEAKING • जवाब दे रही हूँ")
        ExecutionState.EXECUTING -> Triple(CyberYellow, "▲", "EXECUTING: ${actionInfo ?: "DEVICE ACTION"}")
        ExecutionState.ERROR -> Triple(CyberRed, "✕", "PERMISSION / NETWORK NOTICE")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(badgeColor.copy(alpha = 0.12f))
            .border(1.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("status_badge")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = icon,
                color = badgeColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                color = badgeColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.8.sp
            )
        }
    }
}

@Composable
fun CentralVoiceVisualizer(
    state: ExecutionState,
    audioLevel: Float,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "cyber_pulse")

    val rotationAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val dynamicAudioScale by animateFloatAsState(
        targetValue = 1f + (audioLevel * 0.25f),
        label = "audio_scale"
    )

    val activeGlowColor = when (state) {
        ExecutionState.LISTENING -> CyberCyan
        ExecutionState.SPEAKING -> CyberGreen
        ExecutionState.THINKING -> CyberPurple
        ExecutionState.EXECUTING -> CyberYellow
        ExecutionState.ERROR -> CyberRed
        else -> CyberCyan.copy(alpha = 0.6f)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("central_voice_button"),
        contentAlignment = Alignment.Center
    ) {
        // Multi-ring waveform canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.minDimension / 2f - 24.dp.toPx()

            // Concentric cyber orbits
            drawCircle(
                color = activeGlowColor.copy(alpha = 0.08f),
                radius = baseRadius * pulseScale * 1.15f,
                center = center
            )
            drawCircle(
                color = activeGlowColor.copy(alpha = 0.15f),
                radius = baseRadius * pulseScale,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Radiating audio frequency bars around the ring
            val barCount = 36
            val angleStep = (2 * Math.PI / barCount).toFloat()
            for (i in 0 until barCount) {
                val angle = i * angleStep + Math.toRadians(rotationAnim.toDouble()).toFloat()
                val waveHeight = 6.dp.toPx() + (audioLevel * 28.dp.toPx() * ((i % 3 + 1) / 3f))

                val startX = center.x + (baseRadius - 4.dp.toPx()) * cos(angle)
                val startY = center.y + (baseRadius - 4.dp.toPx()) * sin(angle)
                val endX = center.x + (baseRadius + waveHeight) * cos(angle)
                val endY = center.y + (baseRadius + waveHeight) * sin(angle)

                drawLine(
                    color = activeGlowColor.copy(alpha = if (state == ExecutionState.DISCONNECTED) 0.25f else 0.85f),
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }

        // Inner Core Glow Sphere
        Box(
            modifier = Modifier
                .size(150.dp)
                .scale(dynamicAudioScale * pulseScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            CyberDark,
                            CyberSurface,
                            CyberBlack
                        )
                    )
                )
                .border(2.dp, activeGlowColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Futuristic Warrior Emblem inside the core
            Image(
                painter = painterResource(id = R.drawable.ic_warrior_emblem),
                contentDescription = "MAX Warrior Emblem",
                modifier = Modifier
                    .size(95.dp)
                    .scale(if (state == ExecutionState.SPEAKING) 1f + audioLevel * 0.1f else 1f)
            )

            // Dynamic microphone or status overlay icon
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(activeGlowColor.copy(alpha = 0.9f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (state) {
                        ExecutionState.LISTENING -> Icons.Default.Mic
                        ExecutionState.SPEAKING -> Icons.AutoMirrored.Filled.VolumeUp
                        ExecutionState.THINKING -> Icons.Default.GraphicEq
                        else -> Icons.Default.PlayArrow
                    },
                    contentDescription = "Status",
                    tint = CyberBlack,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun ConversationFeedbackCard(
    state: ExecutionState,
    lastHeard: String,
    lastResponse: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("conversation_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface.copy(alpha = 0.85f)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                colors = listOf(CyberBorder, CyberCyan.copy(alpha = 0.3f), CyberBorder)
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // User Speech Section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(CyberBlue)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "USER",
                    color = CyberBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (lastHeard.isNotBlank()) "\"$lastHeard\"" else "\"MAX, YouTube kholo\"",
                color = if (lastHeard.isNotBlank()) CyberSilver else CyberSilverMuted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 16.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // MAX Response Section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(CyberCyan)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MAX",
                    color = CyberCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = lastResponse,
                color = CyberSilver,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp)
            )
        }
    }
}

@Composable
fun QuickActionsRow(onSelectCommand: (String) -> Unit) {
    val quickCommands = listOf(
        "MAX" to "Wake Word Test",
        "YouTube kholo" to "Open YouTube",
        "Wi-Fi settings kholo" to "Wi-Fi Settings",
        "Screenshot lo" to "Take Screenshot",
        "Flashlight on karo" to "Torch ON",
        "Music pause karo" to "Media Pause",
        "Google Maps kholo" to "Maps",
        "Papa ko call karo" to "Voice Call",
        "Aaj mausam kaisa hai?" to "Weather"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "QUICK VOICE COMMANDS",
            color = CyberSilverMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(quickCommands) { (cmd, label) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberSurfaceVariant)
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                        .clickable { onSelectCommand(cmd) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Column {
                        Text(
                            text = cmd,
                            color = CyberCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = label,
                            color = CyberSilverMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsSheet(
    permissions: com.example.model.PermissionStatus,
    onDismiss: () -> Unit,
    onRequestMic: () -> Unit,
    onRequestCall: () -> Unit,
    onRequestContacts: () -> Unit,
    onRequestSms: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberDark,
        scrimColor = Color.Black.copy(alpha = 0.75f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MAX NATIVE CAPABILITIES",
                    color = CyberSilver,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = CyberSilverMuted)
                }
            }

            Text(
                text = "MAX requires legitimate Android permissions to execute supported actions like calls, launching apps, and accessibility navigation.",
                color = CyberSilverMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Accessibility Service Card
            PermissionItem(
                title = "MAX Accessibility Service",
                description = "Enables UI inspection, clicking, scrolling, and global gestures (Home, Back, Screenshot).",
                isGranted = permissions.isAccessibilityEnabled,
                actionLabel = "Enable in Settings",
                onAction = onOpenAccessibilitySettings
            )

            // Microphone
            PermissionItem(
                title = "Microphone (RECORD_AUDIO)",
                description = "Required for continuous voice listening and wake-word detection.",
                isGranted = permissions.hasAudioRecord,
                actionLabel = "Grant Mic",
                onAction = onRequestMic
            )

            // Phone Calls
            PermissionItem(
                title = "Phone Calls (CALL_PHONE)",
                description = "Allows MAX to place calls directly when you ask.",
                isGranted = permissions.hasCallPhone,
                actionLabel = "Grant Calls",
                onAction = onRequestCall
            )

            // Contacts
            PermissionItem(
                title = "Contacts (READ_CONTACTS)",
                description = "Resolves contact names (e.g., 'Papa ko call karo') to phone numbers.",
                isGranted = permissions.hasReadContacts,
                actionLabel = "Grant Contacts",
                onAction = onRequestContacts
            )

            // SMS
            PermissionItem(
                title = "SMS (SEND_SMS)",
                description = "Prepares and sends text messages to permitted contacts.",
                isGranted = permissions.hasSendSms,
                actionLabel = "Grant SMS",
                onAction = onRequestSms
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PermissionItem(
    title: String,
    description: String,
    isGranted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                listOf(
                    CyberBorder,
                    if (isGranted) CyberGreen.copy(alpha = 0.3f) else CyberYellow.copy(alpha = 0.3f)
                )
            )
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isGranted) CyberGreen else CyberYellow,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        color = CyberSilver,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = description,
                    color = CyberSilverMuted,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            if (!isGranted) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberCyan.copy(alpha = 0.2f))
                        .border(1.dp, CyberCyan, RoundedCornerShape(8.dp))
                        .clickable { onAction() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = actionLabel,
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Text(
                    text = "ACTIVE",
                    color = CyberGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun CyberBackgroundGrid(state: ExecutionState, audioLevel: Float) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val step = 48.dp.toPx()
        val gridColor = Color(0xFF1E293B).copy(alpha = 0.12f)

        for (x in 0..(size.width / step).toInt()) {
            drawLine(
                color = gridColor,
                start = Offset(x * step, 0f),
                end = Offset(x * step, size.height),
                strokeWidth = 0.8f
            )
        }
        for (y in 0..(size.height / step).toInt()) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y * step),
                end = Offset(size.width, y * step),
                strokeWidth = 0.8f
            )
        }
    }
}
