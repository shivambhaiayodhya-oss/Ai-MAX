package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF06090F)
val CyberDark = Color(0xFF0B101C)
val CyberSurface = Color(0xFF131B2E)
val CyberSurfaceVariant = Color(0xFF1C273E)
val CyberBorder = Color(0xFF273856)

val CyberCyan = Color(0xFF00F0FF)
val CyberCyanDim = Color(0xFF0284C7)
val CyberBlue = Color(0xFF38BDF8)
val CyberSilver = Color(0xFFF1F5F9)
val CyberSilverMuted = Color(0xFF94A3B8)

val CyberGreen = Color(0xFF10B981)
val CyberYellow = Color(0xFFFBBF24)
val CyberRed = Color(0xFFF43F5E)
val CyberPurple = Color(0xFFA855F7)
