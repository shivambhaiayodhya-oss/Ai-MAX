package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.example.accessibility.MAXAccessibilityService
import com.example.audio.MAXBackgroundService
import com.example.audio.MAXServiceState
import com.example.model.ExecutionState
import com.example.model.PermissionStatus
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val context: Context
        get() = getApplication()

    val assistantState: StateFlow<ExecutionState> =
        MAXServiceState.state

    val lastHeardText: StateFlow<String> =
        MAXServiceState.lastHeardText

    val lastResponseText: StateFlow<String> =
        MAXServiceState.lastResponseText

    val executedActionInfo: StateFlow<String?> =
        MAXServiceState.actionInfo

    val audioLevel: StateFlow<Float> =
        MAXServiceState.audioLevel

    val continuousMode: StateFlow<Boolean> =
        MAXServiceState.active

    private val _permissionStatus =
        kotlinx.coroutines.flow.MutableStateFlow(
            PermissionStatus()
        )

    val permissionStatus: StateFlow<PermissionStatus> =
        _permissionStatus

    init {
        refreshPermissions()
    }

    fun refreshPermissions() {

        val hasMic =
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

        val hasCall =
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED

        val hasContacts =
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED

        val hasSms =
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED

        val isAccessibility =
            MAXAccessibilityService.isEnabled

        _permissionStatus.value =
            PermissionStatus(
                hasAudioRecord = hasMic,
                hasCallPhone = hasCall,
                hasReadContacts = hasContacts,
                hasSendSms = hasSms,
                isAccessibilityEnabled = isAccessibility
            )
    }

    fun onVoiceOrbClick() {

        if (MAXServiceState.active.value) {
            deactivateContinuousMode()
        } else {
            activateContinuousMode()
        }
    }

    fun activateContinuousMode() {

        refreshPermissions()

        if (!_permissionStatus.value.hasAudioRecord) {

            MAXServiceState.setState(
                ExecutionState.ERROR
            )

            MAXServiceState.setResponseText(
                "Microphone permission chahiye Boss."
            )

            return
        }

        MAXServiceState.setActive(true)

        MAXServiceState.setState(
            ExecutionState.LISTENING
        )

        MAXServiceState.setHeardText(
            "सुन रही हूँ..."
        )

        MAXServiceState.setActionInfo(null)

        vibratePhone()

        startBackgroundService()
    }

    fun deactivateContinuousMode() {

        MAXServiceState.setActive(false)

        stopBackgroundService()

        MAXServiceState.setAudioLevel(0f)
    }

    private fun startBackgroundService() {

        try {

            val intent =
                Intent(
                    context,
                    MAXBackgroundService::class.java
                ).apply {
                    action =
                        MAXBackgroundService.ACTION_START
                }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                ContextCompat.startForegroundService(
                    context,
                    intent
                )

            } else {

                context.startService(intent)
            }

        } catch (e: Exception) {

            MAXServiceState.setActive(false)

            MAXServiceState.setState(
                ExecutionState.ERROR
            )

            MAXServiceState.setResponseText(
                "MAX background service start nahi ho saki Boss."
            )
        }
    }

    private fun stopBackgroundService() {

        try {

            val intent =
                Intent(
                    context,
                    MAXBackgroundService::class.java
                ).apply {
                    action =
                        MAXBackgroundService.ACTION_STOP
                }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                ContextCompat.startForegroundService(
                    context,
                    intent
                )

            } else {

                context.startService(intent)
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun startListening() {
        activateContinuousMode()
    }

    fun stopListening() {
        deactivateContinuousMode()
    }

    fun interrupt() {
        deactivateContinuousMode()
    }

    fun processUserInput(rawText: String) {

        if (rawText.isBlank()) return

        MAXServiceState.setHeardText(
            rawText.trim()
        )
    }

    private fun vibratePhone() {

        try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

                val vibratorManager =
                    context.getSystemService(
                        VibratorManager::class.java
                    )

                vibratorManager
                    ?.defaultVibrator
                    ?.vibrate(
                        VibrationEffect.createOneShot(
                            45L,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )

            } else {

                @Suppress("DEPRECATION")
                val vibrator =
                    context.getSystemService(
                        Context.VIBRATOR_SERVICE
                    ) as? Vibrator

                @Suppress("DEPRECATION")
                vibrator?.vibrate(45L)
            }

        } catch (_: Exception) {
        }
    }

    override fun onCleared() {
        super.onCleared()
    }
}
