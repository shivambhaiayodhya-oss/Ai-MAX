package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = CyberBlack,
    primaryContainer = CyberDark,
    onPrimaryContainer = CyberCyan,
    secondary = CyberBlue,
    onSecondary = CyberBlack,
    secondaryContainer = CyberSurfaceVariant,
    onSecondaryContainer = CyberSilver,
    tertiary = CyberSilver,
    onTertiary = CyberBlack,
    background = CyberBlack,
    onBackground = CyberSilver,
    surface = CyberDark,
    onSurface = CyberSilver,
    surfaceVariant = CyberSurface,
    onSurfaceVariant = CyberSilverMuted,
    outline = CyberBorder,
    error = CyberRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
