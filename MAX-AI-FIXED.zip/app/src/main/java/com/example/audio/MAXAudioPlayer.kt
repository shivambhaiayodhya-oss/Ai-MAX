package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class MAXAudioPlayer(
    private val context: Context
) {

    companion object {
        private const val TAG = "MAXAudioPlayer"
        private const val UTTERANCE_ID = "MAX_RESPONSE"
    }

    private var tts: TextToSpeech? = null
    private var isReady = false

    private val _speakingAmplitude =
        MutableStateFlow(0f)

    val speakingAmplitude: StateFlow<Float> =
        _speakingAmplitude.asStateFlow()

    private var currentOnStart: (() -> Unit)? = null
    private var currentOnDone: (() -> Unit)? = null

    init {
        initializeTts()
    }

    private fun initializeTts() {

        tts = TextToSpeech(
            context.applicationContext
        ) { status ->

            if (status == TextToSpeech.SUCCESS) {

                isReady = true

                configureVoice()

                Log.i(
                    TAG,
                    "TTS initialized successfully"
                )

            } else {

                isReady = false

                Log.e(
                    TAG,
                    "TTS initialization failed: $status"
                )
            }
        }

        tts?.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {

                override fun onStart(
                    utteranceId: String?
                ) {
                    _speakingAmplitude.value =
                        0.7f

                    currentOnStart?.invoke()
                }

                override fun onDone(
                    utteranceId: String?
                ) {
                    _speakingAmplitude.value =
                        0f

                    currentOnDone?.invoke()

                    currentOnStart = null
                    currentOnDone = null
                }

                override fun onError(
                    utteranceId: String?
                ) {
                    _speakingAmplitude.value =
                        0f

                    currentOnDone?.invoke()

                    currentOnStart = null
                    currentOnDone = null
                }
            }
        )
    }

    private fun configureVoice() {

        val engine = tts ?: return

        /*
         * Prefer Indian Hindi.
         */
        val hindiIndia =
            Locale("hi", "IN")

        val result =
            engine.setLanguage(hindiIndia)

        Log.d(
            TAG,
            "Hindi language result: $result"
        )

        /*
         * Try to select the best available Hindi
         * voice installed on the device.
         */
        val voices =
            engine.voices

        val preferredVoice =
            voices
                ?.filter { voice ->

                    val locale =
                        voice.locale

                    locale.language == "hi" &&
                            (
                                locale.country.isEmpty() ||
                                locale.country.equals(
                                    "IN",
                                    ignoreCase = true
                                )
                            ) &&
                            !voice.isNetworkConnectionRequired
                }
                ?.sortedBy { voice ->

                    /*
                     * Prefer Indian Hindi voice.
                     */
                    if (
                        voice.locale.country
                            .equals(
                                "IN",
                                ignoreCase = true
                            )
                    ) {
                        0
                    } else {
                        1
                    }
                }
                ?.firstOrNull()

        if (preferredVoice != null) {

            try {
                engine.voice =
                    preferredVoice

                Log.i(
                    TAG,
                    "Selected Hindi voice: ${preferredVoice.name}"
                )
            } catch (e: Exception) {

                Log.w(
                    TAG,
                    "Could not select Hindi voice",
                    e
                )
            }
        }

        /*
         * Natural conversational settings.
         */
        engine.setPitch(1.08f)
        engine.setSpeechRate(0.98f)
    }

    fun speak(
        text: String,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {}
    ) {

        if (text.isBlank()) {
            onDone()
            return
        }

        if (!isReady) {

            Log.w(
                TAG,
                "TTS not ready"
            )

            onDone()
            return
        }

        stop()

        currentOnStart = onStart
        currentOnDone = onDone

        /*
         * Small pronunciation cleanup.
         *
         * We only normalize obvious formatting.
         * We don't translate the user's text because
         * that can change the intended meaning.
         */
        val spokenText =
            prepareHindiText(text)

        val params =
            Bundle().apply {
                putFloat(
                    TextToSpeech.Engine.KEY_PARAM_VOLUME,
                    1.0f
                )
            }

        val result =
            tts?.speak(
                spokenText,
                TextToSpeech.QUEUE_FLUSH,
                params,
                UTTERANCE_ID
            )

        if (
            result == TextToSpeech.ERROR
        ) {

            Log.e(
                TAG,
                "TTS speak failed"
            )

            _speakingAmplitude.value =
                0f

            currentOnDone?.invoke()

            currentOnStart = null
            currentOnDone = null
        }
    }

    private fun prepareHindiText(
        text: String
    ): String {

        return text
            .replace(
                Regex("\\s+"),
                " "
            )
            .replace(
                "MAX AI",
                "मैक्स एआई",
                ignoreCase = true
            )
            .trim()
    }

    fun stop() {

        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.w(
                TAG,
                "TTS stop failed",
                e
            )
        }

        _speakingAmplitude.value =
            0f

        currentOnStart = null
        currentOnDone = null
    }

    fun destroy() {

        stop()

        try {
            tts?.shutdown()
        } catch (e: Exception) {
            Log.w(
                TAG,
                "TTS shutdown failed",
                e
            )
        }

        tts = null
        isReady = false
    }
}
