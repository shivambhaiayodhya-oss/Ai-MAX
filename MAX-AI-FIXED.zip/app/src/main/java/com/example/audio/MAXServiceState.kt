package com.example.audio

import com.example.model.ExecutionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object MAXServiceState {

    private val _state =
        MutableStateFlow(ExecutionState.DISCONNECTED)

    val state: StateFlow<ExecutionState> =
        _state.asStateFlow()

    private val _lastHeardText =
        MutableStateFlow("")

    val lastHeardText: StateFlow<String> =
        _lastHeardText.asStateFlow()

    private val _lastResponseText =
        MutableStateFlow("")

    val lastResponseText: StateFlow<String> =
        _lastResponseText.asStateFlow()

    private val _actionInfo =
        MutableStateFlow<String?>(null)

    val actionInfo: StateFlow<String?> =
        _actionInfo.asStateFlow()

    private val _audioLevel =
        MutableStateFlow(0f)

    val audioLevel: StateFlow<Float> =
        _audioLevel.asStateFlow()

    private val _active =
        MutableStateFlow(false)

    val active: StateFlow<Boolean> =
        _active.asStateFlow()

    fun setActive(value: Boolean) {
        _active.value = value

        if (!value) {
            _state.value = ExecutionState.DISCONNECTED
            _audioLevel.value = 0f
        }
    }

    fun setState(value: ExecutionState) {
        _state.value = value
    }

    fun setHeardText(value: String) {
        _lastHeardText.value = value
    }

    fun setResponseText(value: String) {
        _lastResponseText.value = value
    }

    fun setActionInfo(value: String?) {
        _actionInfo.value = value
    }

    fun setAudioLevel(value: Float) {
        _audioLevel.value = value.coerceIn(0f, 1f)
    }

    fun reset() {
        _active.value = false
        _state.value = ExecutionState.DISCONNECTED
        _lastHeardText.value = ""
        _lastResponseText.value = ""
        _actionInfo.value = null
        _audioLevel.value = 0f
    }
}
