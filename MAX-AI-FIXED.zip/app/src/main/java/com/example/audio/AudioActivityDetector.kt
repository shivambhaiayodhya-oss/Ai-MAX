package com.example.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class AudioActivityDetector(
    private val scope: CoroutineScope
) {

    private var audioRecord: AudioRecord? = null
    private var monitorJob: Job? = null

    private var active = false
    private var speechTriggered = false

    private val sampleRate = 16000

    private val bufferSize =
        maxOf(
            AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ),
            2048
        )

    var onSpeechStarted: (() -> Unit)? = null
    var onAudioLevel: ((Float) -> Unit)? = null

    fun start() {

        if (active) return

        stop()

        try {

            audioRecord =
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize * 2
                )

            if (
                audioRecord?.state !=
                AudioRecord.STATE_INITIALIZED
            ) {
                audioRecord?.release()
                audioRecord = null
                return
            }

            active = true
            speechTriggered = false

            audioRecord?.startRecording()

            monitorJob =
                scope.launch(Dispatchers.Default) {

                    val buffer =
                        ShortArray(1024)

                    var consecutiveSpeechFrames = 0

                    while (
                        isActive &&
                        active
                    ) {

                        val read =
                            audioRecord?.read(
                                buffer,
                                0,
                                buffer.size
                            ) ?: -1

                        if (read <= 0) {
                            delay(20L)
                            continue
                        }

                        var sum = 0.0

                        for (i in 0 until read) {
                            val sample =
                                buffer[i].toDouble()

                            sum += sample * sample
                        }

                        val rms =
                            sqrt(
                                sum / read
                            )

                        val normalized =
                            (
                                rms / 32768.0
                            )
                                .coerceIn(
                                    0.0,
                                    1.0
                                )
                                .toFloat()

                        onAudioLevel?.invoke(
                            normalized
                        )

                        /*
                         * Voice activity threshold.
                         *
                         * Small background sounds should
                         * not start SpeechRecognizer.
                         */
                        if (normalized > 0.035f) {

                            consecutiveSpeechFrames++

                        } else {

                            consecutiveSpeechFrames = 0
                        }

                        /*
                         * Require a few continuous speech
                         * frames before opening recognizer.
                         *
                         * This prevents random noise from
                         * triggering recognition.
                         */
                        if (
                            !speechTriggered &&
                            consecutiveSpeechFrames >= 3
                        ) {

                            speechTriggered = true

                            scope.launch(
                                Dispatchers.Main
                            ) {
                                if (active) {
                                    onSpeechStarted?.invoke()
                                }
                            }

                            break
                        }

                        delay(20L)
                    }
                }

        } catch (_: SecurityException) {

            active = false
            release()

        } catch (_: Exception) {

            active = false
            release()
        }
    }

    fun stop() {

        active = false

        monitorJob?.cancel()
        monitorJob = null

        release()

        onAudioLevel?.invoke(0f)
    }

    private fun release() {

        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }

        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }

        audioRecord = null
    }

    fun destroy() {
        stop()
        onSpeechStarted = null
        onAudioLevel = null
    }
}
