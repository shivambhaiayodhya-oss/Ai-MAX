package com.example.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SpeechManager(
    private val context: Context
) {

    companion object {
        private const val TAG = "SpeechManager"
    }

    private var speechRecognizer: SpeechRecognizer? = null

    private var continuousMode = false
    private var isStarting = false

    private var currentOnResult: ((String) -> Unit)? = null
    private var currentOnPartial: ((String) -> Unit)? = null
    private var currentOnError: ((String) -> Unit)? = null

    private val _micVolume =
        MutableStateFlow(0f)

    val micVolume: StateFlow<Float> =
        _micVolume.asStateFlow()

    private val _isListening =
        MutableStateFlow(false)

    val isListening: StateFlow<Boolean> =
        _isListening.asStateFlow()

    init {
        initRecognizer()
    }

    private fun initRecognizer() {

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e(TAG, "Speech recognition unavailable")
            return
        }

        try {

            speechRecognizer =
                SpeechRecognizer
                    .createSpeechRecognizer(
                        context.applicationContext
                    )
                    .apply {
                        setRecognitionListener(
                            createListener()
                        )
                    }

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Recognizer initialization failed",
                e
            )
        }
    }

    private fun createListener(): RecognitionListener {

        return object : RecognitionListener {

            override fun onReadyForSpeech(
                params: Bundle?
            ) {

                isStarting = false
                _isListening.value = true

                Log.d(
                    TAG,
                    "Ready for speech"
                )
            }

            override fun onBeginningOfSpeech() {

                Log.d(
                    TAG,
                    "Beginning of speech"
                )
            }

            override fun onRmsChanged(
                rmsdB: Float
            ) {

                val normalized =
                    ((rmsdB + 2f) / 12f)
                        .coerceIn(0f, 1f)

                _micVolume.value =
                    normalized
            }

            override fun onBufferReceived(
                buffer: ByteArray?
            ) {
            }

            override fun onEndOfSpeech() {

                _isListening.value = false
                _micVolume.value = 0f

                Log.d(
                    TAG,
                    "End of speech"
                )
            }

            override fun onError(
                error: Int
            ) {

                isStarting = false

                _isListening.value = false
                _micVolume.value = 0f

                Log.w(
                    TAG,
                    "Recognition error: $error"
                )

                /*
                 * IMPORTANT:
                 *
                 * SpeechManager no longer restarts
                 * recognition by itself.
                 *
                 * MAXBackgroundService owns the
                 * restart lifecycle.
                 */

                val message =
                    when (error) {

                        SpeechRecognizer.ERROR_NO_MATCH ->
                            "Kuch samajh nahi aaya, Boss."

                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "Boss, main sun rahi hoon."

                        SpeechRecognizer.ERROR_NETWORK ->
                            "Internet connection check karein Boss."

                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Microphone permission chahiye Boss."

                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                            "Voice system busy hai Boss."

                        SpeechRecognizer.ERROR_AUDIO ->
                            "Microphone audio mein problem aa gayi Boss."

                        SpeechRecognizer.ERROR_CLIENT ->
                            "Voice recognition restart karna padega Boss."

                        else ->
                            "Voice recognition error ($error)"
                    }

                if (!continuousMode) {
                    currentOnError?.invoke(message)
                } else {
                    /*
                     * In continuous mode the service
                     * receives the error and decides
                     * when to restart.
                     */
                    currentOnError?.invoke(message)
                }
            }

            override fun onResults(
                results: Bundle?
            ) {

                isStarting = false

                _isListening.value = false
                _micVolume.value = 0f

                val matches =
                    results?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )

                val text =
                    matches
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()

                Log.d(
                    TAG,
                    "Recognized: $text"
                )

                if (text.isNotBlank()) {

                    currentOnResult?.invoke(
                        text
                    )

                } else {

                    currentOnError?.invoke(
                        "Kuch samajh nahi aaya, Boss."
                    )
                }
            }

            override fun onPartialResults(
                partialResults: Bundle?
            ) {

                val matches =
                    partialResults?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )

                val partial =
                    matches
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()

                if (partial.isNotBlank()) {

                    currentOnPartial?.invoke(
                        partial
                    )
                }
            }

            override fun onEvent(
                eventType: Int,
                params: Bundle?
            ) {
            }
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onPartial: (String) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {

        continuousMode = false

        startInternal(
            onResult,
            onPartial,
            onError
        )
    }

    fun startContinuousListening(
        onResult: (String) -> Unit,
        onPartial: (String) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {

        continuousMode = true

        startInternal(
            onResult,
            onPartial,
            onError
        )
    }

    private fun startInternal(
        onResult: (String) -> Unit,
        onPartial: (String) -> Unit,
        onError: (String) -> Unit
    ) {

        currentOnResult = onResult
        currentOnPartial = onPartial
        currentOnError = onError

        if (isStarting) {
            Log.d(
                TAG,
                "Recognition start already in progress"
            )
            return
        }

        if (speechRecognizer == null) {
            initRecognizer()
        }

        val recognizer =
            speechRecognizer

        if (recognizer == null) {

            onError(
                "Voice recognition available nahi hai."
            )

            return
        }

        val intent =
            Intent(
                RecognizerIntent.ACTION_RECOGNIZE_SPEECH
            ).apply {

                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )

                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE,
                    "hi-IN"
                )

                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,
                    "hi-IN"
                )

                putExtra(
                    "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                    arrayOf(
                        "en-IN",
                        "en-US"
                    )
                )

                putExtra(
                    RecognizerIntent.EXTRA_PARTIAL_RESULTS,
                    true
                )

                putExtra(
                    RecognizerIntent.EXTRA_MAX_RESULTS,
                    3
                )

                /*
                 * Give the recognizer more time to wait
                 * for natural Hindi speech.
                 */

                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                    1800L
                )

                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,
                    1200L
                )

                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,
                    800L
                )

                putExtra(
                    RecognizerIntent.EXTRA_CALLING_PACKAGE,
                    context.packageName
                )
            }

        try {

            /*
             * Cancel only the previous recognizer
             * session before a genuinely new session.
             *
             * There is NO internal restart loop here.
             */

            try {
                recognizer.cancel()
            } catch (_: Exception) {
            }

            isStarting = true

            recognizer.startListening(
                intent
            )

            Log.d(
                TAG,
                "startListening requested"
            )

        } catch (e: Exception) {

            isStarting = false

            _isListening.value = false
            _micVolume.value = 0f

            Log.e(
                TAG,
                "startListening failed",
                e
            )

            onError(
                "Microphone start nahi ho saka Boss."
            )
        }
    }

    fun stopListening() {

        continuousMode = false
        isStarting = false

        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {

            Log.w(
                TAG,
                "stopListening failed",
                e
            )
        }

        _isListening.value = false
        _micVolume.value = 0f
    }

    fun cancel() {

        continuousMode = false
        isStarting = false

        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {

            Log.w(
                TAG,
                "cancel failed",
                e
            )
        }

        _isListening.value = false
        _micVolume.value = 0f
    }

    fun destroy() {

        continuousMode = false
        isStarting = false

        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {

            Log.w(
                TAG,
                "Recognizer destroy failed",
                e
            )
        }

        speechRecognizer = null

        _isListening.value = false
        _micVolume.value = 0f

        currentOnResult = null
        currentOnPartial = null
        currentOnError = null
    }
}
