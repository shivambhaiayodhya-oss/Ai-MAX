package com.example.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class MAXScreenStateReceiver : BroadcastReceiver() {

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {
        when (intent.action) {

            Intent.ACTION_SCREEN_OFF -> {
                MAXBackgroundService.onScreenLocked()
            }

            Intent.ACTION_SCREEN_ON -> {
                MAXBackgroundService.onScreenUnlocked()
            }
        }
    }
}
