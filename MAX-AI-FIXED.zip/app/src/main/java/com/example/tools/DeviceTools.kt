package com.example.tools

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.example.accessibility.MAXAccessibilityService
import com.example.model.ToolResult

object DeviceTools {

    private val KNOWN_APPS = mapOf(
        "youtube" to "com.google.android.youtube",
        "yt" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "insta" to "com.instagram.android",
        "instagram" to "com.instagram.android",
        "chrome" to "com.android.chrome",
        "google" to "com.google.android.googlequicksearchbox",
        "maps" to "com.google.android.apps.maps",
        "spotify" to "com.spotify.music",
        "gmail" to "com.google.android.gm",
        "telegram" to "org.telegram.messenger",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "play store" to "com.android.vending",
        "playstore" to "com.android.vending"
    )

    fun openApp(context: Context, appName: String): ToolResult {
        val cleanName = appName.trim().lowercase()

        // Direct intent handling for system actions often referred to as apps
        when {
            cleanName.contains("camera") || cleanName.contains("cam") -> {
                return openCamera(context)
            }
            cleanName.contains("gallery") || cleanName.contains("photos") -> {
                return openGallery(context)
            }
            cleanName.contains("settings") || cleanName.contains("setting") -> {
                return openSettings(context, "general")
            }
            cleanName.contains("clock") || cleanName.contains("alarm") -> {
                return openAlarmApp(context)
            }
        }

        val pm = context.packageManager

        // Check known app aliases first
        for ((key, pkg) in KNOWN_APPS) {
            if (cleanName.contains(key)) {
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return ToolResult(
                        success = true,
                        hindiResponse = "Yes Boss. $appName khol rahi hoon.",
                        actionType = "OPEN_APP",
                        technicalDetail = "Launched $pkg"
                    )
                }
            }
        }

        // Search through all installed applications
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            for (info in resolveInfos) {
                val label = info.loadLabel(pm).toString().lowercase()
                if (label.contains(cleanName) || cleanName.contains(label)) {
                    val launchIntent = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return ToolResult(
                            success = true,
                            hindiResponse = "Yes Boss. ${info.loadLabel(pm)} khol rahi hoon.",
                            actionType = "OPEN_APP",
                            technicalDetail = "Launched ${info.activityInfo.packageName}"
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return ToolResult(
            success = false,
            hindiResponse = "Ye app phone mein installed nahi hai.",
            actionType = "OPEN_APP",
            technicalDetail = "App not found: $appName"
        )
    }

    fun openWebsite(context: Context, rawUrl: String): ToolResult {
        var url = rawUrl.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. Website open kar rahi hoon.",
                actionType = "OPEN_WEBSITE"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Website open nahi ho saki.",
                actionType = "OPEN_WEBSITE",
                technicalDetail = e.message
            )
        }
    }

    fun openSettings(context: Context, settingType: String): ToolResult {
        val lower = settingType.lowercase().trim()
        val action = when {
            lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("internet") -> Settings.ACTION_WIFI_SETTINGS
            lower.contains("bluetooth") || lower.contains("bt") -> Settings.ACTION_BLUETOOTH_SETTINGS
            lower.contains("display") || lower.contains("brightness") || lower.contains("screen") -> Settings.ACTION_DISPLAY_SETTINGS
            lower.contains("battery") || lower.contains("power") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            lower.contains("sound") || lower.contains("volume") || lower.contains("audio") -> Settings.ACTION_SOUND_SETTINGS
            lower.contains("app") -> Settings.ACTION_APPLICATION_SETTINGS
            lower.contains("accessibility") -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. Settings khol rahi hoon.",
                actionType = "OPEN_SETTINGS"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Settings open karne mein dikkat aayi.",
                actionType = "OPEN_SETTINGS",
                technicalDetail = e.message
            )
        }
    }

    fun makeCall(context: Context, recipient: String): ToolResult {
        val clean = recipient.trim()
        var phoneNumber: String? = null
        var contactName: String = clean

        // Check if digits or phone number
        if (clean.matches(Regex("^[+0-9\\-\\s]+$"))) {
            phoneNumber = clean.replace("\\s".toRegex(), "")
        } else {
            // Search contact
            val contact = ContactTools.findContactNumber(context, clean)
            if (contact != null) {
                phoneNumber = contact.number
                contactName = contact.name
            }
        }

        if (phoneNumber == null) {
            return if (!ContactTools.hasContactsPermission(context)) {
                ToolResult(
                    success = false,
                    hindiResponse = "Contacts access ki permission chahiye Boss.",
                    actionType = "MAKE_CALL",
                    technicalDetail = "READ_CONTACTS permission missing"
                )
            } else {
                ToolResult(
                    success = false,
                    hindiResponse = "Boss, '$clean' ka number contacts mein nahi mila.",
                    actionType = "MAKE_CALL"
                )
            }
        }

        val hasCallPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        return try {
            val intent = if (hasCallPermission) {
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
            } else {
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
            }.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val msg = if (hasCallPermission) {
                "Yes Boss. $contactName ko call mila rahi hoon."
            } else {
                "Yes Boss. $contactName ke liye dialer open kar rahi hoon."
            }
            ToolResult(true, msg, actionType = "MAKE_CALL")
        } catch (e: Exception) {
            ToolResult(
                false,
                "Call initiate nahi ho payi.",
                actionType = "MAKE_CALL",
                technicalDetail = e.message
            )
        }
    }

    fun sendSms(context: Context, recipient: String, message: String): ToolResult {
        val clean = recipient.trim()
        var phoneNumber: String? = null
        var contactName: String = clean

        if (clean.matches(Regex("^[+0-9\\-\\s]+$"))) {
            phoneNumber = clean.replace("\\s".toRegex(), "")
        } else {
            val contact = ContactTools.findContactNumber(context, clean)
            if (contact != null) {
                phoneNumber = contact.number
                contactName = contact.name
            }
        }

        if (phoneNumber == null) {
            phoneNumber = clean
        }

        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. $contactName ke liye SMS taiyaar hai.",
                actionType = "SEND_SMS"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "SMS initiate karne mein samasya aayi.",
                actionType = "SEND_SMS",
                technicalDetail = e.message
            )
        }
    }

    fun openMaps(context: Context, destination: String): ToolResult {
        return try {
            val query = Uri.encode(destination.trim())
            val uri = Uri.parse("geo:0,0?q=$query")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$query")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. $destination ka map khol rahi hoon.",
                actionType = "OPEN_MAPS"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Maps kholne mein error aaya.",
                actionType = "OPEN_MAPS",
                technicalDetail = e.message
            )
        }
    }

    fun openCamera(context: Context): ToolResult {
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. Camera khol rahi hoon.",
                actionType = "OPEN_CAMERA"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Camera open nahi ho saka.",
                actionType = "OPEN_CAMERA",
                technicalDetail = e.message
            )
        }
    }

    fun openGallery(context: Context): ToolResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. Gallery khol rahi hoon.",
                actionType = "OPEN_GALLERY"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Gallery open nahi ho saki.",
                actionType = "OPEN_GALLERY",
                technicalDetail = e.message
            )
        }
    }

    private fun openAlarmApp(context: Context): ToolResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. Alarms khol rahi hoon.",
                actionType = "SHOW_ALARMS"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Alarms nahi khul saka.",
                actionType = "SHOW_ALARMS",
                technicalDetail = e.message
            )
        }
    }

    fun setAlarm(context: Context, hour: Int, minute: Int, message: String): ToolResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message.ifEmpty { "MAX Alarm" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val timeStr = String.format("%02d:%02d", hour, minute)
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. Subah $timeStr baje ka alarm laga diya hai.",
                actionType = "SET_ALARM"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Alarm set karne mein problem aayi.",
                actionType = "SET_ALARM",
                technicalDetail = e.message
            )
        }
    }

    fun setTimer(context: Context, seconds: Int, message: String): ToolResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message.ifEmpty { "MAX Timer" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val min = seconds / 60
            val sec = seconds % 60
            val label = if (min > 0) "$min minute" else "$sec second"
            ToolResult(
                success = true,
                hindiResponse = "Yes Boss. $label ka timer shuru kar diya hai.",
                actionType = "SET_TIMER"
            )
        } catch (e: Exception) {
            ToolResult(
                success = false,
                hindiResponse = "Timer set nahi ho saka.",
                actionType = "SET_TIMER",
                technicalDetail = e.message
            )
        }
    }

    fun controlMedia(context: Context, action: String): ToolResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return ToolResult(false, "Audio service uplabdh nahi hai.", actionType = "MEDIA_CONTROL")

        val clean = action.trim().lowercase()
        val keyEventCode = when {
            clean.contains("pause") -> KeyEvent.KEYCODE_MEDIA_PAUSE
            clean.contains("play") || clean.contains("chalao") || clean.contains("resume") -> KeyEvent.KEYCODE_MEDIA_PLAY
            clean.contains("next") || clean.contains("agla") -> KeyEvent.KEYCODE_MEDIA_NEXT
            clean.contains("prev") || clean.contains("previous") || clean.contains("pichla") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            clean.contains("stop") -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }

        return try {
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyEventCode))
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyEventCode))
            val msg = when (keyEventCode) {
                KeyEvent.KEYCODE_MEDIA_PAUSE -> "Yes Boss. Music pause kar diya."
                KeyEvent.KEYCODE_MEDIA_PLAY -> "Yes Boss. Music play kar rahi hoon."
                KeyEvent.KEYCODE_MEDIA_NEXT -> "Yes Boss. Next track laga diya."
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> "Yes Boss. Previous track par chale gaye."
                else -> "Yes Boss. Media control command execute kar di."
            }
            ToolResult(true, msg, actionType = "MEDIA_CONTROL")
        } catch (e: Exception) {
            ToolResult(false, "Media control allow nahi hua.", actionType = "MEDIA_CONTROL", technicalDetail = e.message)
        }
    }

    fun toggleFlashlight(context: Context, enable: Boolean): ToolResult {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            if (cameraManager == null) {
                return ToolResult(false, "Camera hardware detect nahi hua.", actionType = "FLASHLIGHT")
            }
            val cameraId = cameraManager.cameraIdList.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enable)
                val msg = if (enable) "Yes Boss. Flashlight on kar di hai." else "Yes Boss. Flashlight off kar di hai."
                ToolResult(true, msg, actionType = "FLASHLIGHT")
            } else {
                ToolResult(false, "Flashlight camera unit nahi mila.", actionType = "FLASHLIGHT")
            }
        } catch (e: Exception) {
            ToolResult(false, "Flashlight control allow nahi hua.", actionType = "FLASHLIGHT", technicalDetail = e.message)
        }
    }

    fun takeScreenshot(): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(
                success = false,
                hindiResponse = "Screenshot lene ke liye MAX Accessibility Service enable karein.",
                actionType = "SCREENSHOT",
                technicalDetail = "AccessibilityService not connected"
            )
        }
        val success = MAXAccessibilityService.takeScreenshot()
        return if (success) {
            ToolResult(true, "Yes Boss. Screenshot le liya hai.", actionType = "SCREENSHOT")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "SCREENSHOT")
        }
    }

    fun goHome(): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(
                false,
                "Home screen ke liye MAX Accessibility Service on karein.",
                actionType = "GO_HOME"
            )
        }
        val res = MAXAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        return if (res) {
            ToolResult(true, "Yes Boss. Home screen par aa gaye.", actionType = "GO_HOME")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "GO_HOME")
        }
    }

    fun goBack(): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(
                false,
                "Back jane ke liye MAX Accessibility Service on karein.",
                actionType = "GO_BACK"
            )
        }
        val res = MAXAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        return if (res) {
            ToolResult(true, "Yes Boss. Back kar diya.", actionType = "GO_BACK")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "GO_BACK")
        }
    }

    fun openRecents(): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(
                false,
                "Recent apps ke liye MAX Accessibility Service on karein.",
                actionType = "OPEN_RECENTS"
            )
        }
        val res = MAXAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
        return if (res) {
            ToolResult(true, "Yes Boss. Recent apps open kar diye.", actionType = "OPEN_RECENTS")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "OPEN_RECENTS")
        }
    }

    fun openNotifications(): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(
                false,
                "Notifications panel ke liye MAX Accessibility Service on karein.",
                actionType = "OPEN_NOTIFICATIONS"
            )
        }
        val res = MAXAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        return if (res) {
            ToolResult(true, "Yes Boss. Notifications panel open kar diya.", actionType = "OPEN_NOTIFICATIONS")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "OPEN_NOTIFICATIONS")
        }
    }

    fun openQuickSettings(): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(
                false,
                "Quick Settings ke liye MAX Accessibility Service on karein.",
                actionType = "OPEN_QUICK_SETTINGS"
            )
        }
        val res = MAXAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        return if (res) {
            ToolResult(true, "Yes Boss. Quick settings open kar diye.", actionType = "OPEN_QUICK_SETTINGS")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "OPEN_QUICK_SETTINGS")
        }
    }

    fun clickElement(description: String): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(false, "Screen par click karne ke liye MAX Accessibility Service enable karein.", actionType = "CLICK")
        }
        val clicked = MAXAccessibilityService.clickByText(description)
        return if (clicked) {
            ToolResult(true, "Yes Boss. '$description' par click kiya.", actionType = "CLICK")
        } else {
            ToolResult(false, "Screen par '$description' element nahi mila.", actionType = "CLICK")
        }
    }

    fun scroll(direction: String): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(false, "Scroll karne ke liye MAX Accessibility Service on karein.", actionType = "SCROLL")
        }
        val forward = !direction.lowercase().contains("up") && !direction.lowercase().contains("back")
        val scrolled = MAXAccessibilityService.scroll(forward)
        return if (scrolled) {
            ToolResult(true, "Yes Boss. Scroll kar diya.", actionType = "SCROLL")
        } else {
            ToolResult(false, "Ye action Android ne allow nahi kiya.", actionType = "SCROLL")
        }
    }

    fun typeText(text: String): ToolResult {
        if (!MAXAccessibilityService.isEnabled) {
            return ToolResult(false, "Text type karne ke liye MAX Accessibility Service on karein.", actionType = "TYPE_TEXT")
        }
        val typed = MAXAccessibilityService.typeText(text)
        return if (typed) {
            ToolResult(true, "Yes Boss. Type kar diya.", actionType = "TYPE_TEXT")
        } else {
            ToolResult(false, "Input field active nahi mila.", actionType = "TYPE_TEXT")
        }
    }
}
