package com.example.ai

import org.json.JSONArray
import org.json.JSONObject

object ToolRegistry {

    fun getToolsJsonArray(): JSONArray {
        val declarations = JSONArray()

        declarations.put(createStringTool(
            "openApp",
            "Open an installed Android application.",
            "appName",
            "Application name."
        ))

        declarations.put(createStringTool(
            "openWebsite",
            "Open a website in the browser.",
            "url",
            "Complete website URL."
        ))

        declarations.put(createStringTool(
            "openSettings",
            "Open an Android settings screen.",
            "setting",
            "Setting such as wifi, bluetooth, display, battery, sound, apps, accessibility or general."
        ))

        declarations.put(createStringTool(
            "makeCall",
            "Call a contact or phone number.",
            "contact",
            "Contact name or phone number."
        ))

        declarations.put(createTwoStringTool(
            "sendSms",
            "Send an SMS.",
            "contact",
            "Contact name or phone number.",
            "message",
            "Message text."
        ))

        declarations.put(createStringTool(
            "openMaps",
            "Open Google Maps and search for a destination.",
            "destination",
            "Place, address or destination."
        ))

        declarations.put(createAlarmTool())
        declarations.put(createTimerTool())

        declarations.put(createStringTool(
            "controlMedia",
            "Control currently playing media.",
            "action",
            "play, pause, next, previous or stop."
        ))

        declarations.put(createBooleanTool(
            "toggleFlashlight",
            "Turn the flashlight on or off.",
            "enable",
            "true for on, false for off."
        ))

        declarations.put(createStringTool(
            "clickElement",
            "Click a visible Android UI element by text or accessibility description.",
            "description",
            "Visible text or content description."
        ))

        declarations.put(createStringTool(
            "longClickElement",
            "Long-press a visible Android UI element by text or accessibility description.",
            "description",
            "Visible text or content description."
        ))

        declarations.put(createTwoNumberTool(
            "tapAt",
            "Tap a screen coordinate when no accessible UI element is available.",
            "x", "Horizontal screen coordinate in pixels.",
            "y", "Vertical screen coordinate in pixels."
        ))

        declarations.put(createSwipeTool())

        declarations.put(createStringTool(
            "typeText",
            "Type text into the currently focused input field.",
            "text",
            "Text to type."
        ))

        declarations.put(createStringTool(
            "scroll",
            "Scroll the current Android screen.",
            "direction",
            "down or up."
        ))

        declarations.put(createStringTool(
            "waitForElement",
            "Wait until a visible UI element appears.",
            "description",
            "Text or accessibility description to wait for."
        ))

        declarations.put(createStringTool(
            "waitForPackage",
            "Wait until a specific Android application becomes active.",
            "packageName",
            "Android package name."
        ))

        declarations.put(createSimpleTool(
            "getScreenText",
            "Read visible text and accessibility descriptions from the current screen."
        ))

        declarations.put(createSimpleTool(
            "takeScreenshot",
            "Take a screenshot of the current screen."
        ))

        declarations.put(createSimpleTool(
            "goHome",
            "Go to the Android home screen."
        ))

        declarations.put(createSimpleTool(
            "goBack",
            "Go back one screen."
        ))

        declarations.put(createSimpleTool(
            "openRecents",
            "Open recent Android applications."
        ))

        declarations.put(createSimpleTool(
            "openNotifications",
            "Open Android notifications."
        ))

        declarations.put(createSimpleTool(
            "openQuickSettings",
            "Open Android quick settings."
        ))

        declarations.put(createSimpleTool(
            "openCamera",
            "Open the camera."
        ))

        declarations.put(createSimpleTool(
            "openGallery",
            "Open the photo gallery."
        ))

        val toolObject = JSONObject().apply {
            put("functionDeclarations", declarations)
        }

        return JSONArray().put(toolObject)
    }

    private fun createStringTool(
        name: String,
        description: String,
        parameterName: String,
        parameterDescription: String
    ): JSONObject {

        val properties = JSONObject().apply {
            put(
                parameterName,
                JSONObject()
                    .put("type", "STRING")
                    .put("description", parameterDescription)
            )
        }

        return JSONObject().apply {
            put("name", name)
            put("description", description)
            put(
                "parameters",
                JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", properties)
                    put(
                        "required",
                        JSONArray().put(parameterName)
                    )
                }
            )
        }
    }

    private fun createTwoStringTool(
        name: String,
        description: String,
        firstName: String,
        firstDescription: String,
        secondName: String,
        secondDescription: String
    ): JSONObject {

        val properties = JSONObject().apply {
            put(
                firstName,
                JSONObject()
                    .put("type", "STRING")
                    .put("description", firstDescription)
            )

            put(
                secondName,
                JSONObject()
                    .put("type", "STRING")
                    .put("description", secondDescription)
            )
        }

        return JSONObject().apply {
            put("name", name)
            put("description", description)

            put(
                "parameters",
                JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", properties)
                    put(
                        "required",
                        JSONArray()
                            .put(firstName)
                            .put(secondName)
                    )
                }
            )
        }
    }

    private fun createBooleanTool(
        name: String,
        description: String,
        parameterName: String,
        parameterDescription: String
    ): JSONObject {

        val properties = JSONObject().apply {
            put(
                parameterName,
                JSONObject()
                    .put("type", "BOOLEAN")
                    .put("description", parameterDescription)
            )
        }

        return JSONObject().apply {
            put("name", name)
            put("description", description)

            put(
                "parameters",
                JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", properties)
                    put(
                        "required",
                        JSONArray().put(parameterName)
                    )
                }
            )
        }
    }

    private fun createTwoNumberTool(
        name: String,
        description: String,
        firstName: String,
        firstDescription: String,
        secondName: String,
        secondDescription: String
    ): JSONObject {
        val properties = JSONObject().apply {
            put(firstName, JSONObject().put("type", "NUMBER").put("description", firstDescription))
            put(secondName, JSONObject().put("type", "NUMBER").put("description", secondDescription))
        }
        return JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", properties)
                put("required", JSONArray().put(firstName).put(secondName))
            })
        }
    }

    private fun createSwipeTool(): JSONObject {
        val properties = JSONObject().apply {
            put("startX", JSONObject().put("type", "NUMBER").put("description", "Starting X coordinate."))
            put("startY", JSONObject().put("type", "NUMBER").put("description", "Starting Y coordinate."))
            put("endX", JSONObject().put("type", "NUMBER").put("description", "Ending X coordinate."))
            put("endY", JSONObject().put("type", "NUMBER").put("description", "Ending Y coordinate."))
            put("durationMs", JSONObject().put("type", "INTEGER").put("description", "Gesture duration in milliseconds, normally 250-900."))
        }
        return JSONObject().apply {
            put("name", "swipe")
            put("description", "Swipe from one screen coordinate to another when semantic scrolling is not enough.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", properties)
                put("required", JSONArray().put("startX").put("startY").put("endX").put("endY"))
            })
        }
    }

    private fun createAlarmTool(): JSONObject {

        val properties = JSONObject().apply {

            put(
                "hour",
                JSONObject()
                    .put("type", "INTEGER")
                    .put("description", "Hour from 0 to 23.")
            )

            put(
                "minute",
                JSONObject()
                    .put("type", "INTEGER")
                    .put("description", "Minute from 0 to 59.")
            )

            put(
                "message",
                JSONObject()
                    .put("type", "STRING")
                    .put("description", "Alarm label.")
            )
        }

        return JSONObject().apply {
            put("name", "setAlarm")
            put("description", "Set an alarm.")

            put(
                "parameters",
                JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", properties)
                    put(
                        "required",
                        JSONArray()
                            .put("hour")
                            .put("minute")
                    )
                }
            )
        }
    }

    private fun createTimerTool(): JSONObject {

        val properties = JSONObject().apply {

            put(
                "seconds",
                JSONObject()
                    .put("type", "INTEGER")
                    .put("description", "Timer duration in seconds.")
            )

            put(
                "message",
                JSONObject()
                    .put("type", "STRING")
                    .put("description", "Timer label.")
            )
        }

        return JSONObject().apply {
            put("name", "setTimer")
            put("description", "Set a countdown timer.")

            put(
                "parameters",
                JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", properties)
                    put(
                        "required",
                        JSONArray().put("seconds")
                    )
                }
            )
        }
    }

    private fun createSimpleTool(
        name: String,
        description: String
    ): JSONObject {

        return JSONObject().apply {
            put("name", name)
            put("description", description)

            put(
                "parameters",
                JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject())
                }
            )
        }
    }
}
