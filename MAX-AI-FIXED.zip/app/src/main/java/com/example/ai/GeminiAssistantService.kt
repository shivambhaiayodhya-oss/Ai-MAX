package com.example.ai

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.model.ToolResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiAssistantService(
    private val context: Context
) {

    companion object {
        private const val TAG = "GeminiAssistantService"

        private const val BASE_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

        private const val MAX_TOOL_ROUNDS = 10
    }

    private val client =
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()

    private val systemPrompt = """
        You are MAX, a young female AI personal assistant for Android.

        LANGUAGE:
        Understand Hindi, Hinglish and English.
        Normally speak natural conversational Hindi/Hinglish.

        PERSONALITY:
        Smart, confident, warm, playful and natural.
        Do not sound robotic.
        Keep spoken responses short.

        IMPORTANT:
        You are an ACTION ASSISTANT, not only a chatbot.

        When the user asks for an Android action,
        use the available tools instead of merely explaining how to do it.

        MULTI-STEP ACTIONS:
        One user command may require many actions.
        Continue until the requested task is actually completed.

        Example:
        "YouTube kholo aur Arijit Singh ka latest song search karke play karo"

        Possible sequence:
        1. openApp("youtube")
        2. waitForPackage("com.google.android.youtube")
        3. getScreenText()
        4. clickElement("Search")
        5. waitForElement("Search")
        6. typeText("Arijit Singh latest song")
        7. inspect the screen again if necessary
        8. click the appropriate visible result
        9. verify that the requested content opened/played

        IMPORTANT UI RULES:
        - Apps can take time to load.
        - After opening an app, use waitForPackage when useful.
        - Before clicking an unknown UI element, use getScreenText when useful.
        - Prefer visible text or accessibility descriptions.
        - Do not blindly repeat a failed action.
        - If an action fails, try a reasonable alternative.
        - Do not claim success unless the tool reports success.
        - If the requested task cannot be completed, clearly say what failed.

        GENERIC COMMANDS:
        Do not hard-code one particular song, person or search query.
        Use the exact information supplied by the user.

        Examples:
        "YouTube kholo" -> openApp("youtube")
        "WhatsApp kholo" -> openApp("whatsapp")
        "Chrome kholo" -> openApp("chrome")
        "Camera kholo" -> openCamera
        "Gallery kholo" -> openGallery
        "WiFi settings kholo" -> openSettings("wifi")
        "Bluetooth settings kholo" -> openSettings("bluetooth")
        "Screenshot lo" -> takeScreenshot
        "Ghar ka rasta dikhao" -> openMaps("ghar")
        "5 minute ka timer lagao" -> setTimer(300)

        SCREEN UNDERSTANDING:
        getScreenText returns visible text and accessibility descriptions.
        Use that information to decide the next action.

        SEARCH:
        For a search task:
        1. Open the requested app.
        2. Wait for the app.
        3. Inspect the screen if necessary.
        4. Find and click the search control.
        5. Type the user's exact search query.
        6. Inspect/wait for results.
        7. Select the appropriate visible result.
        8. Verify when possible.

        SECURITY:
        Never bypass PIN, password, OTP, CAPTCHA, biometric,
        UPI security or other security controls.

        CONVERSATION:
        If the user is simply talking or asking a normal question,
        answer naturally without using an action tool.

        After tools finish:
        Give one short natural Hindi/Hinglish response.
        Do not describe every internal step.
        Do not repeat the entire user command.
    """.trimIndent()

    suspend fun processQuery(
        userInput: String
    ): Pair<String, ToolResult?> =
        withContext(Dispatchers.IO) {

            val input = userInput.trim()

            if (input.isBlank()) {
                return@withContext Pair(
                    "Boss, kuch suna nahi. Dobara boliye.",
                    null
                )
            }

            val fastResult =
                tryLocalFastPath(input)

            if (fastResult != null) {
                return@withContext Pair(
                    fastResult.hindiResponse,
                    fastResult
                )
            }

            val apiKey =
                BuildConfig.GEMINI_API_KEY

            if (
                apiKey.isNullOrBlank() ||
                apiKey == "MY_GEMINI_API_KEY"
            ) {
                return@withContext fallback(input)
            }

            try {
                runGeminiLoop(
                    apiKey,
                    input
                )
            } catch (e: Exception) {

                Log.e(
                    TAG,
                    "Gemini processing failed",
                    e
                )

                fallback(input)
            }
        }

    private fun runGeminiLoop(
        apiKey: String,
        userInput: String
    ): Pair<String, ToolResult?> {

        val contents = JSONArray()

        contents.put(
            JSONObject().apply {
                put("role", "user")

                put(
                    "parts",
                    JSONArray().put(
                        JSONObject().put(
                            "text",
                            userInput
                        )
                    )
                )
            }
        )

        var lastToolResult: ToolResult? = null

        for (round in 0 until MAX_TOOL_ROUNDS) {

            Log.d(
                TAG,
                "Tool round ${round + 1}/$MAX_TOOL_ROUNDS"
            )

            val requestJson =
                buildRequestJson(contents)

            val body =
                requestJson
                    .toString()
                    .toRequestBody(
                        "application/json".toMediaType()
                    )

            val request =
                Request.Builder()
                    .url(
                        "$BASE_URL?key=$apiKey"
                    )
                    .post(body)
                    .build()

            client.newCall(request).execute().use { response ->

                val responseText =
                    response.body?.string().orEmpty()

                if (!response.isSuccessful) {

                    Log.e(
                        TAG,
                        "Gemini API ${response.code}: $responseText"
                    )

                    return fallback(userInput)
                }

                val json =
                    JSONObject(responseText)

                val candidates =
                    json.optJSONArray("candidates")

                val candidate =
                    candidates?.optJSONObject(0)
                        ?: return Pair(
                            "Boss, Gemini se response nahi mila.",
                            lastToolResult
                        )

                val modelContent =
                    candidate.optJSONObject("content")
                        ?: return Pair(
                            "Boss, Gemini response incomplete hai.",
                            lastToolResult
                        )

                val modelParts =
                    modelContent.optJSONArray("parts")
                        ?: return Pair(
                            "Boss, Gemini response incomplete hai.",
                            lastToolResult
                        )

                /*
                 * Add the model turn with its role.
                 */
                contents.put(
                    JSONObject().apply {
                        put("role", "model")
                        put("parts", modelParts)
                    }
                )

                val functionResponses =
                    JSONArray()

                var foundFunction =
                    false

                var finalText: String? =
                    null

                for (i in 0 until modelParts.length()) {

                    val part =
                        modelParts.optJSONObject(i)
                            ?: continue

                    val functionCall =
                        part.optJSONObject(
                            "functionCall"
                        )

                    if (functionCall != null) {

                        foundFunction = true

                        val name =
                            functionCall.optString(
                                "name"
                            )

                        val args =
                            functionCall.optJSONObject(
                                "args"
                            ) ?: JSONObject()

                        val argsMap =
                            jsonObjectToMap(args)

                        Log.d(
                            TAG,
                            "Executing $name : $argsMap"
                        )

                        val result =
                            ToolExecutor.execute(
                                context,
                                name,
                                argsMap
                            )

                        lastToolResult =
                            result

                        val resultText =
                            buildToolResultText(
                                name,
                                result
                            )

                        functionResponses.put(
                            JSONObject().apply {

                                put(
                                    "functionResponse",
                                    JSONObject().apply {

                                        put(
                                            "name",
                                            name
                                        )

                                        put(
                                            "response",
                                            JSONObject().apply {
                                                put(
                                                    "success",
                                                    result.success
                                                )

                                                put(
                                                    "message",
                                                    resultText
                                                )
                                            }
                                        )
                                    }
                                )
                            }
                        )
                    }

                    val text =
                        part.optString(
                            "text",
                            ""
                        ).trim()

                    if (text.isNotBlank()) {
                        finalText = text
                    }
                }

                /*
                 * No tool call means Gemini has finished.
                 */
                if (!foundFunction) {

                    if (!finalText.isNullOrBlank()) {
                        return Pair(
                            finalText!!,
                            lastToolResult
                        )
                    }

                    return Pair(
                        lastToolResult?.hindiResponse
                            ?: "Boss, kaam complete ho gaya.",
                        lastToolResult
                    )
                }

                /*
                 * Send tool results back to Gemini.
                 * Gemini can now decide the next action.
                 */
                if (functionResponses.length() > 0) {

                    contents.put(
                        JSONObject().apply {

                            put(
                                "role",
                                "user"
                            )

                            put(
                                "parts",
                                functionResponses
                            )
                        }
                    )
                }
            }
        }

        return Pair(
            lastToolResult?.hindiResponse
                ?: "Boss, command complete karne mein limit aa gayi.",
            lastToolResult
        )
    }

    private fun buildToolResultText(
        toolName: String,
        result: ToolResult
    ): String {

        val base =
            result.hindiResponse.trim()

        if (toolName != "getScreenText") {
            return base
        }

        /*
         * Screen text is intentionally returned to Gemini
         * so it can decide what to click next.
         */
        return if (base.isNotBlank()) {
            "Current visible screen information:\n$base"
        } else {
            "No readable screen information was found."
        }
    }

    private fun jsonObjectToMap(
        json: JSONObject
    ): Map<String, Any?> {

        val result =
            mutableMapOf<String, Any?>()

        val keys =
            json.keys()

        while (keys.hasNext()) {

            val key =
                keys.next()

            result[key] =
                json.get(key)
        }

        return result
    }

    private fun buildRequestJson(
        contents: JSONArray
    ): JSONObject {

        val systemInstruction =
            JSONObject().apply {

                put(
                    "parts",
                    JSONArray().put(
                        JSONObject().put(
                            "text",
                            systemPrompt
                        )
                    )
                )
            }

        val generationConfig =
            JSONObject().apply {
                put("temperature", 0.4)
                put("topP", 0.9)
                put("maxOutputTokens", 512)
            }

        return JSONObject().apply {

            put(
                "systemInstruction",
                systemInstruction
            )

            put(
                "contents",
                contents
            )

            put(
                "tools",
                ToolRegistry.getToolsJsonArray()
            )

            put(
                "generationConfig",
                generationConfig
            )
        }
    }

    private fun tryLocalFastPath(
        input: String
    ): ToolResult? {

        val lower =
            input.lowercase().trim()

        if (
            lower == "max" ||
            lower == "मैक्स"
        ) {
            return ToolResult(
                success = true,
                hindiResponse = "Yes Boss.",
                actionType = "WAKE_WORD"
            )
        }

        if (
            containsAny(
                lower,
                "youtube",
                "यूट्यूब",
                "यु ट्यूब"
            ) &&
            containsAny(
                lower,
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openApp",
                mapOf(
                    "appName" to "youtube"
                )
            )
        }

        if (
            containsAny(
                lower,
                "whatsapp",
                "व्हाट्सऐप",
                "व्हाट्सएप"
            ) &&
            containsAny(
                lower,
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openApp",
                mapOf(
                    "appName" to "whatsapp"
                )
            )
        }

        if (
            containsAny(
                lower,
                "instagram",
                "इंस्टाग्राम"
            ) &&
            containsAny(
                lower,
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openApp",
                mapOf(
                    "appName" to "instagram"
                )
            )
        }

        if (
            lower.contains("chrome") &&
            containsAny(
                lower,
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openApp",
                mapOf(
                    "appName" to "chrome"
                )
            )
        }

        if (
            containsAny(
                lower,
                "camera",
                "कैमरा"
            ) &&
            containsAny(
                lower,
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openCamera",
                emptyMap()
            )
        }

        if (
            containsAny(
                lower,
                "gallery",
                "गैलरी"
            ) &&
            containsAny(
                lower,
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openGallery",
                emptyMap()
            )
        }

        if (
            containsAny(
                lower,
                "wifi",
                "वाईफाई"
            ) &&
            containsAny(
                lower,
                "setting",
                "सेटिंग",
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openSettings",
                mapOf(
                    "setting" to "wifi"
                )
            )
        }

        if (
            containsAny(
                lower,
                "bluetooth",
                "ब्लूटूथ"
            ) &&
            containsAny(
                lower,
                "setting",
                "सेटिंग",
                "khol",
                "खोल",
                "open",
                "ओपन"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "openSettings",
                mapOf(
                    "setting" to "bluetooth"
                )
            )
        }

        if (
            containsAny(
                lower,
                "screenshot",
                "स्क्रीनशॉट"
            ) &&
            containsAny(
                lower,
                "lo",
                "ले",
                "take",
                "लो"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "takeScreenshot",
                emptyMap()
            )
        }

        if (
            containsAny(
                lower,
                "home",
                "होम"
            ) &&
            containsAny(
                lower,
                "jao",
                "जाओ",
                "go"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "goHome",
                emptyMap()
            )
        }

        if (
            containsAny(
                lower,
                "back",
                "वापस"
            ) &&
            containsAny(
                lower,
                "karo",
                "करो",
                "jao",
                "जाओ"
            )
        ) {
            return ToolExecutor.execute(
                context,
                "goBack",
                emptyMap()
            )
        }

        return null
    }

    private fun containsAny(
        text: String,
        vararg values: String
    ): Boolean {

        return values.any {
            text.contains(it)
        }
    }

    private fun fallback(
        input: String
    ): Pair<String, ToolResult?> {

        val lower =
            input.lowercase()

        return when {

            lower.contains("kaun ho") ||
                    lower.contains("who are you") ||
                    lower.contains("कौन हो") -> {

                Pair(
                    "Main MAX hoon Boss, aapki personal AI assistant. Command dijiye.",
                    null
                )
            }

            lower.contains("kaise ho") ||
                    lower.contains("how are you") ||
                    lower.contains("कैसी हो") ||
                    lower.contains("कैसे हो") -> {

                Pair(
                    "Full power mein Boss! Aap bas command dijiye.",
                    null
                )
            }

            else -> {

                Pair(
                    "Boss, samajh gayi. Thoda aur clearly bataiye kya karna hai.",
                    null
                )
            }
        }
    }
}
