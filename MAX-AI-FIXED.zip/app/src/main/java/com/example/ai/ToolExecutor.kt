package com.example.ai

import android.content.Context
import com.example.model.ToolResult
import com.example.tools.DeviceTools

object ToolExecutor {

    fun execute(
        context: Context,
        toolName: String,
        args: Map<String, Any?>
    ): ToolResult {

        return when (toolName) {

            "openApp" -> {
                DeviceTools.openApp(
                    context,
                    args["appName"]?.toString() ?: ""
                )
            }

            "openWebsite" -> {
                DeviceTools.openWebsite(
                    context,
                    args["url"]?.toString() ?: ""
                )
            }

            "openSettings" -> {
                DeviceTools.openSettings(
                    context,
                    args["setting"]?.toString() ?: "general"
                )
            }

            "makeCall" -> {
                DeviceTools.makeCall(
                    context,
                    args["contact"]?.toString()
                        ?: args["number"]?.toString()
                        ?: ""
                )
            }

            "sendSms" -> {
                DeviceTools.sendSms(
                    context,
                    args["contact"]?.toString() ?: "",
                    args["message"]?.toString() ?: ""
                )
            }

            "openMaps" -> {
                DeviceTools.openMaps(
                    context,
                    args["destination"]?.toString()
                        ?: args["query"]?.toString()
                        ?: ""
                )
            }

            "setAlarm" -> {
                val hour =
                    (args["hour"] as? Number)?.toInt()
                        ?: 7

                val minute =
                    (args["minute"] as? Number)?.toInt()
                        ?: 0

                val message =
                    args["message"]?.toString()
                        ?: "Alarm"

                DeviceTools.setAlarm(
                    context,
                    hour,
                    minute,
                    message
                )
            }

            "setTimer" -> {
                val seconds =
                    (args["seconds"] as? Number)?.toInt()
                        ?: 60

                val message =
                    args["message"]?.toString()
                        ?: "Timer"

                DeviceTools.setTimer(
                    context,
                    seconds,
                    message
                )
            }

            "controlMedia" -> {
                DeviceTools.controlMedia(
                    context,
                    args["action"]?.toString()
                        ?: "toggle"
                )
            }

            "toggleFlashlight" -> {
                val enable =
                    args["enable"] as? Boolean
                        ?: true

                DeviceTools.toggleFlashlight(
                    context,
                    enable
                )
            }

            "takeScreenshot" -> {
                DeviceTools.takeScreenshot()
            }

            "goHome" -> {
                DeviceTools.goHome()
            }

            "goBack" -> {
                DeviceTools.goBack()
            }

            "openRecents" -> {
                DeviceTools.openRecents()
            }

            "openNotifications" -> {
                DeviceTools.openNotifications()
            }

            "openQuickSettings" -> {
                DeviceTools.openQuickSettings()
            }

            "openCamera" -> {
                DeviceTools.openCamera(context)
            }

            "openGallery" -> {
                DeviceTools.openGallery(context)
            }

            "clickElement" -> {
                val description =
                    args["description"]?.toString()
                        ?: ""

                if (description.isBlank()) {
                    ToolResult(
                        success = false,
                        hindiResponse = "Boss, kis element par click karna hai?",
                        actionType = "CLICK_ELEMENT"
                    )
                } else {
                    val success =
                        com.example.accessibility
                            .MAXAccessibilityService
                            .clickByText(description)

                    ToolResult(
                        success = success,
                        hindiResponse =
                            if (success) {
                                "Element click ho gaya."
                            } else {
                                "Element nahi mila."
                            },
                        actionType = "CLICK_ELEMENT"
                    )
                }
            }

            "longClickElement" -> {
                val description = args["description"]?.toString()?.trim().orEmpty()
                val success = description.isNotBlank() &&
                    com.example.accessibility.MAXAccessibilityService.longClickByText(description)
                ToolResult(
                    success = success,
                    hindiResponse = if (success) "Long press ho gaya." else "Element nahi mila ya long press fail hua.",
                    actionType = "LONG_CLICK_ELEMENT"
                )
            }

            "tapAt" -> {
                val x = (args["x"] as? Number)?.toFloat() ?: 0f
                val y = (args["y"] as? Number)?.toFloat() ?: 0f
                val success = com.example.accessibility.MAXAccessibilityService.tapAt(x, y)
                ToolResult(
                    success = success,
                    hindiResponse = if (success) "Screen par tap ho gaya." else "Coordinate tap fail hua.",
                    actionType = "TAP_AT"
                )
            }

            "swipe" -> {
                val startX = (args["startX"] as? Number)?.toFloat() ?: 0f
                val startY = (args["startY"] as? Number)?.toFloat() ?: 0f
                val endX = (args["endX"] as? Number)?.toFloat() ?: 0f
                val endY = (args["endY"] as? Number)?.toFloat() ?: 0f
                val duration = (args["durationMs"] as? Number)?.toLong() ?: 450L
                val success = com.example.accessibility.MAXAccessibilityService.swipe(
                    startX, startY, endX, endY, duration
                )
                ToolResult(
                    success = success,
                    hindiResponse = if (success) "Swipe ho gaya." else "Swipe fail hua.",
                    actionType = "SWIPE"
                )
            }

            "typeText" -> {
                val text =
                    args["text"]?.toString()
                        ?: ""

                if (text.isBlank()) {
                    ToolResult(
                        success = false,
                        hindiResponse = "Boss, type karne ke liye text nahi mila.",
                        actionType = "TYPE_TEXT"
                    )
                } else {
                    val success =
                        com.example.accessibility
                            .MAXAccessibilityService
                            .typeText(text)

                    ToolResult(
                        success = success,
                        hindiResponse =
                            if (success) {
                                "Text type ho gaya."
                            } else {
                                "Input field nahi mila."
                            },
                        actionType = "TYPE_TEXT"
                    )
                }
            }

            "scroll" -> {
                val direction =
                    args["direction"]?.toString()
                        ?.lowercase()
                        ?: "down"

                val forward =
                    direction != "up"

                val success =
                    com.example.accessibility
                        .MAXAccessibilityService
                        .scroll(forward)

                ToolResult(
                    success = success,
                    hindiResponse =
                        if (success) {
                            "Screen scroll ho gayi."
                        } else {
                            "Scroll karne wali screen nahi mili."
                        },
                    actionType = "SCROLL"
                )
            }

            "waitForElement" -> {
                val description =
                    args["description"]?.toString()
                        ?: ""

                if (description.isBlank()) {
                    ToolResult(
                        success = false,
                        hindiResponse = "Wait karne ke liye element ka naam nahi mila.",
                        actionType = "WAIT_FOR_ELEMENT"
                    )
                } else {

                    val success =
                        com.example.accessibility
                            .MAXAccessibilityService
                            .waitForText(
                                description,
                                6000L
                            )

                    ToolResult(
                        success = success,
                        hindiResponse =
                            if (success) {
                                "Element screen par aa gaya."
                            } else {
                                "Element time ke andar nahi mila."
                            },
                        actionType = "WAIT_FOR_ELEMENT"
                    )
                }
            }

            "waitForPackage" -> {
                val packageName =
                    args["packageName"]?.toString()
                        ?: ""

                if (packageName.isBlank()) {
                    ToolResult(
                        success = false,
                        hindiResponse = "App package nahi mila.",
                        actionType = "WAIT_FOR_PACKAGE"
                    )
                } else {

                    val success =
                        com.example.accessibility
                            .MAXAccessibilityService
                            .waitForPackage(
                                packageName,
                                6000L
                            )

                    ToolResult(
                        success = success,
                        hindiResponse =
                            if (success) {
                                "App active ho gaya."
                            } else {
                                "App active hone ka wait timeout ho gaya."
                            },
                        actionType = "WAIT_FOR_PACKAGE"
                    )
                }
            }

            "getScreenText" -> {

                val screenText =
                    com.example.accessibility
                        .MAXAccessibilityService
                        .getScreenText()

                ToolResult(
                    success = screenText.isNotBlank(),
                    hindiResponse =
                        if (screenText.isNotBlank()) {
                            screenText
                        } else {
                            "Screen par readable text nahi mila."
                        },
                    actionType = "GET_SCREEN_TEXT"
                )
            }

            else -> {
                ToolResult(
                    success = false,
                    hindiResponse =
                        "Boss, ye action abhi available nahi hai.",
                    actionType = toolName
                )
            }
        }
    }
}
