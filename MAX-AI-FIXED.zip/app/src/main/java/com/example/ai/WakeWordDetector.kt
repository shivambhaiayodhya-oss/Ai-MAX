package com.example.ai

object WakeWordDetector {

    data class DetectionResult(
        val hasWakeWord: Boolean,
        val isOnlyWakeWord: Boolean,
        val remainingCommand: String
    )

    private val WAKE_PATTERNS = listOf(
        Regex("^\\s*(hey\\s+|ok\\s+|hello\\s+|oye\\s+|arre\\s+)?max\\b", RegexOption.IGNORE_CASE),
        Regex("^\\s*(hey\\s+|ok\\s+|hello\\s+|oye\\s+|arre\\s+)?मैक्स\\b", RegexOption.IGNORE_CASE),
        Regex("^\\s*(hey\\s+|ok\\s+|hello\\s+|oye\\s+|arre\\s+)?maix\\b", RegexOption.IGNORE_CASE),
        Regex("^\\s*(hey\\s+|ok\\s+|hello\\s+|oye\\s+|arre\\s+)?mex\\b", RegexOption.IGNORE_CASE)
    )

    fun checkWakeWord(text: String): DetectionResult {
        val trimmed = text.trim()
        for (pattern in WAKE_PATTERNS) {
            val match = pattern.find(trimmed)
            if (match != null) {
                val remaining = trimmed.substring(match.range.last + 1).trim()
                    .removePrefix(",").removePrefix(".").removePrefix("-").trim()
                return DetectionResult(
                    hasWakeWord = true,
                    isOnlyWakeWord = remaining.isEmpty(),
                    remainingCommand = remaining
                )
            }
        }

        // Also check if text simply equals "max" or "मैक्स" anywhere in short phrases
        val lower = trimmed.lowercase()
        if (lower == "max" || lower == "मैक्स" || lower == "hey max" || lower == "ok max") {
            return DetectionResult(hasWakeWord = true, isOnlyWakeWord = true, remainingCommand = "")
        }

        return DetectionResult(
            hasWakeWord = false,
            isOnlyWakeWord = false,
            remainingCommand = trimmed
        )
    }
}
