package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Bundle
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel

class MAXAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MAXAccessibility"

        @Volatile
        var instance: MAXAccessibilityService? = null
            private set

        @Volatile
        var activePackage: String = ""
            private set

        val isEnabled: Boolean
            get() = instance != null

        fun performGlobalAction(action: Int): Boolean {
            return instance?.performGlobal(action) ?: false
        }

        fun clickByText(text: String): Boolean {
            return instance?.clickElement(text) ?: false
        }

        fun longClickByText(text: String): Boolean {
            return instance?.longClickElement(text) ?: false
        }

        fun tapAt(x: Float, y: Float): Boolean {
            return instance?.tapAtPoint(x, y) ?: false
        }

        fun swipe(
            startX: Float,
            startY: Float,
            endX: Float,
            endY: Float,
            durationMs: Long = 450L
        ): Boolean {
            return instance?.swipeGesture(
                startX, startY, endX, endY, durationMs
            ) ?: false
        }

        fun typeText(text: String): Boolean {
            return instance?.typeTextIntoActive(text) ?: false
        }

        fun scroll(forward: Boolean): Boolean {
            return instance?.scrollActiveWindow(forward) ?: false
        }

        fun waitForText(
            text: String,
            timeoutMs: Long = 5000L
        ): Boolean {
            return instance?.waitForElement(text, timeoutMs) ?: false
        }

        fun waitForPackage(
            packageName: String,
            timeoutMs: Long = 5000L
        ): Boolean {
            return instance?.waitForPackageName(packageName, timeoutMs) ?: false
        }

        fun getScreenText(): String {
            return instance?.getVisibleScreenText() ?: ""
        }

        fun getActivePackageName(): String {
            return activePackage
        }

        fun takeScreenshot(): Boolean {
            val service = instance ?: return false

            return if (
                android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.P
            ) {
                service.performGlobal(
                    GLOBAL_ACTION_TAKE_SCREENSHOT
                )
            } else {
                false
            }
        }
    }

    private val serviceScope =
        CoroutineScope(Dispatchers.Main)

    private var lastEventTime = 0L
    private var waitJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()

        instance = this

        val info = serviceInfo ?: AccessibilityServiceInfo()

        info.apply {
            eventTypes =
                AccessibilityEvent.TYPES_ALL_MASK

            feedbackType =
                AccessibilityServiceInfo.FEEDBACK_GENERIC

            flags =
                flags or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS

            notificationTimeout = 50
        }

        serviceInfo = info

        Log.i(
            TAG,
            "MAX Accessibility Service connected"
        )
    }

    override fun onAccessibilityEvent(
        event: AccessibilityEvent?
    ) {
        event ?: return

        lastEventTime =
            System.currentTimeMillis()

        val packageName =
            event.packageName?.toString()

        if (!packageName.isNullOrBlank()) {
            activePackage = packageName
        }
    }

    override fun onInterrupt() {
        Log.w(
            TAG,
            "MAX Accessibility Service interrupted"
        )
    }

    override fun onDestroy() {
        waitJob?.cancel()

        if (instance == this) {
            instance = null
            activePackage = ""
        }

        serviceScope.cancel()

        super.onDestroy()

        Log.i(
            TAG,
            "MAX Accessibility Service destroyed"
        )
    }

    fun performGlobal(action: Int): Boolean {
        return try {
            performGlobalAction(action)
        } catch (e: Exception) {
            Log.e(
                TAG,
                "Global action failed: $action",
                e
            )
            false
        }
    }

    fun clickElement(query: String): Boolean {

        val root =
            rootInActiveWindow
                ?: return false

        val cleanQuery =
            query.trim().lowercase()

        if (cleanQuery.isBlank()) {
            return false
        }

        val nodes =
            mutableListOf<AccessibilityNodeInfo>()

        findMatchingNodes(
            root,
            cleanQuery,
            nodes
        )

        for (node in nodes) {
            if (isExactMatch(node, cleanQuery)) {
                if (performClick(node)) {
                    return true
                }
            }
        }

        for (node in nodes) {
            if (performClick(node)) {
                return true
            }
        }

        return false
    }

    private fun isExactMatch(
        node: AccessibilityNodeInfo,
        query: String
    ): Boolean {

        val text =
            node.text
                ?.toString()
                ?.trim()
                ?.lowercase()

        val description =
            node.contentDescription
                ?.toString()
                ?.trim()
                ?.lowercase()

        return text == query ||
            description == query
    }

    private fun performClick(
        node: AccessibilityNodeInfo
    ): Boolean {

        var target: AccessibilityNodeInfo? = node

        repeat(6) {

            if (target == null) {
                return false
            }

            if (target?.isClickable == true) {
                return try {
                    target?.performAction(
                        AccessibilityNodeInfo.ACTION_CLICK
                    ) == true
                } catch (_: Exception) {
                    false
                }
            }

            target = target?.parent
        }

        return false
    }

    private fun findMatchingNodes(
        node: AccessibilityNodeInfo,
        query: String,
        result: MutableList<AccessibilityNodeInfo>
    ) {

        val text =
            node.text
                ?.toString()
                ?.lowercase()
                ?: ""

        val description =
            node.contentDescription
                ?.toString()
                ?.lowercase()
                ?: ""

        if (
            text.contains(query) ||
            description.contains(query)
        ) {
            result.add(node)
        }

        for (i in 0 until node.childCount) {

            val child =
                node.getChild(i)
                    ?: continue

            findMatchingNodes(
                child,
                query,
                result
            )
        }
    }

    fun longClickElement(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val cleanQuery = query.trim().lowercase()
        if (cleanQuery.isBlank()) return false

        val nodes = mutableListOf<AccessibilityNodeInfo>()
        findMatchingNodes(root, cleanQuery, nodes)

        val node = nodes.firstOrNull { isExactMatch(it, cleanQuery) }
            ?: nodes.firstOrNull()
            ?: return false

        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.isEmpty) return false

        val x = bounds.exactCenterX()
        val y = bounds.exactCenterY()
        return longPressAtPoint(x, y)
    }

    fun tapAtPoint(x: Float, y: Float): Boolean {
        return dispatchGestureAtPoint(x, y, x, y, 80L)
    }

    fun swipeGesture(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ): Boolean {
        return dispatchGestureAtPoint(
            startX, startY, endX, endY, durationMs.coerceIn(100L, 2000L)
        )
    }

    private fun longPressAtPoint(x: Float, y: Float): Boolean {
        return dispatchGestureAtPoint(x, y, x, y, 700L)
    }

    private fun dispatchGestureAtPoint(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) {
            return false
        }

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(
                android.accessibilityservice.GestureDescription.StrokeDescription(
                    path, 0L, durationMs
                )
            )
            .build()

        return try {
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            Log.e(TAG, "Gesture dispatch failed", e)
            false
        }
    }

    fun typeTextIntoActive(
        text: String
    ): Boolean {

        val root =
            rootInActiveWindow
                ?: return false

        val focused =
            root.findFocus(
                AccessibilityNodeInfo.FOCUS_INPUT
            )

        val editable =
            focused
                ?: findFirstEditable(root)

        editable ?: return false

        return try {

            val arguments =
                Bundle().apply {
                    putCharSequence(
                        AccessibilityNodeInfo
                            .ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                        text
                    )
                }

            editable.performAction(
                AccessibilityNodeInfo.ACTION_SET_TEXT,
                arguments
            )

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Failed to type text",
                e
            )

            false
        }
    }

    private fun findFirstEditable(
        node: AccessibilityNodeInfo
    ): AccessibilityNodeInfo? {

        if (node.isEditable) {
            return node
        }

        for (i in 0 until node.childCount) {

            val child =
                node.getChild(i)
                    ?: continue

            val result =
                findFirstEditable(child)

            if (result != null) {
                return result
            }
        }

        return null
    }

    fun scrollActiveWindow(
        forward: Boolean
    ): Boolean {

        val root =
            rootInActiveWindow
                ?: return false

        val scrollable =
            findBestScrollable(root)
                ?: return false

        val action =
            if (forward) {
                AccessibilityNodeInfo
                    .ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo
                    .ACTION_SCROLL_BACKWARD
            }

        return try {
            scrollable.performAction(action)
        } catch (_: Exception) {
            false
        }
    }

    private fun findBestScrollable(
        node: AccessibilityNodeInfo
    ): AccessibilityNodeInfo? {

        if (node.isScrollable) {
            return node
        }

        for (i in 0 until node.childCount) {

            val child =
                node.getChild(i)
                    ?: continue

            val result =
                findBestScrollable(child)

            if (result != null) {
                return result
            }
        }

        return null
    }

    fun waitForElement(
        text: String,
        timeoutMs: Long = 5000L
    ): Boolean {

        val endTime =
            System.currentTimeMillis() + timeoutMs

        while (
            System.currentTimeMillis() < endTime
        ) {

            if (clickableElementExists(text)) {
                return true
            }

            Thread.sleep(150)
        }

        return false
    }

    private fun clickableElementExists(
        query: String
    ): Boolean {

        val root =
            rootInActiveWindow
                ?: return false

        val cleanQuery =
            query.trim().lowercase()

        return containsMatchingNode(
            root,
            cleanQuery
        )
    }

    private fun containsMatchingNode(
        node: AccessibilityNodeInfo,
        query: String
    ): Boolean {

        val text =
            node.text
                ?.toString()
                ?.lowercase()
                ?: ""

        val description =
            node.contentDescription
                ?.toString()
                ?.lowercase()
                ?: ""

        if (
            text.contains(query) ||
            description.contains(query)
        ) {
            return true
        }

        for (i in 0 until node.childCount) {

            val child =
                node.getChild(i)
                    ?: continue

            if (
                containsMatchingNode(
                    child,
                    query
                )
            ) {
                return true
            }
        }

        return false
    }

    fun waitForPackageName(
        packageName: String,
        timeoutMs: Long = 5000L
    ): Boolean {

        val endTime =
            System.currentTimeMillis() + timeoutMs

        while (
            System.currentTimeMillis() < endTime
        ) {

            if (
                activePackage.equals(
                    packageName,
                    ignoreCase = true
                )
            ) {
                return true
            }

            val currentRoot =
                rootInActiveWindow

            val currentPackage =
                currentRoot
                    ?.packageName
                    ?.toString()

            if (
                currentPackage.equals(
                    packageName,
                    ignoreCase = true
                )
            ) {
                activePackage = packageName
                return true
            }

            Thread.sleep(150)
        }

        return false
    }

    fun getVisibleScreenText(): String {

        val root =
            rootInActiveWindow
                ?: return ""

        val result =
            StringBuilder()

        collectVisibleText(
            root,
            result
        )

        return result
            .toString()
            .trim()
            .take(8000)
    }

    private fun collectVisibleText(
        node: AccessibilityNodeInfo,
        result: StringBuilder
    ) {

        val text =
            node.text
                ?.toString()
                ?.trim()

        val description =
            node.contentDescription
                ?.toString()
                ?.trim()

        if (!text.isNullOrBlank()) {
            appendUnique(
                result,
                text
            )
        }

        if (
            !description.isNullOrBlank() &&
            description != text
        ) {
            appendUnique(
                result,
                description
            )
        }

        for (i in 0 until node.childCount) {

            val child =
                node.getChild(i)
                    ?: continue

            collectVisibleText(
                child,
                result
            )
        }
    }

    private fun appendUnique(
        result: StringBuilder,
        value: String
    ) {

        if (value.isBlank()) {
            return
        }

        val current =
            result.toString()

        if (!current.contains(value)) {
            if (result.isNotEmpty()) {
                result.append(" | ")
            }

            result.append(value)
        }
    }
}
