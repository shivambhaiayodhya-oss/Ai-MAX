package com.max.ai

/**
 * MAX Smart Action Engine
 *
 * Turns a sequence of tool actions into a resilient execution loop:
 * PLAN -> ACT -> OBSERVE -> VERIFY -> RECOVER
 *
 * This class is deliberately UI/framework agnostic so it can be connected to
 * the existing ToolExecutor/Accessibility service without replacing them.
 */
class MaxSmartActionEngine(
    private val executor: Executor,
    private val observer: Observer,
    private val verifier: Verifier,
    private val maxRetries: Int = 2
) {
    data class Action(
        val name: String,
        val arguments: Map<String, Any?> = emptyMap()
    )

    data class StepResult(
        val action: Action,
        val success: Boolean,
        val message: String = "",
        val attempts: Int = 1
    )

    data class ExecutionResult(
        val success: Boolean,
        val results: List<StepResult>,
        val message: String
    )

    interface Executor {
        suspend fun execute(action: Action): String
    }

    interface Observer {
        suspend fun observe(): String
    }

    interface Verifier {
        suspend fun verify(action: Action, executionResult: String, screenState: String): Boolean
    }

    suspend fun run(actions: List<Action>): ExecutionResult {
        val results = mutableListOf<StepResult>()

        for (original in actions) {
            var attempt = 0
            var lastMessage = ""
            var success = false

            while (attempt <= maxRetries && !success) {
                attempt++
                lastMessage = executor.execute(original)

                // Give the target app/UI a chance to settle.
                val screen = observer.observe()
                success = verifier.verify(original, lastMessage, screen)

                if (!success && attempt <= maxRetries) {
                    recover(original, attempt)
                }
            }

            results += StepResult(
                action = original,
                success = success,
                message = lastMessage,
                attempts = attempt
            )

            if (!success) {
                return ExecutionResult(
                    success = false,
                    results = results,
                    message = "MAX could not verify: ${original.name}"
                )
            }
        }

        return ExecutionResult(
            success = true,
            results = results,
            message = "Task completed successfully."
        )
    }

    private suspend fun recover(action: Action, attempt: Int) {
        // Conservative recovery: re-observation is performed by the next loop.
        // App-specific recovery can be added by the existing ToolExecutor.
        observer.observe()
    }
}
