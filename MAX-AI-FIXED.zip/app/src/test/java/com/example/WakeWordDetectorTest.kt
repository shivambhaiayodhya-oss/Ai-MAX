package com.example

import com.example.ai.WakeWordDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordDetectorTest {

    @Test
    fun testWakeWordAlone() {
        val result = WakeWordDetector.checkWakeWord("MAX")
        assertTrue(result.hasWakeWord)
        assertTrue(result.isOnlyWakeWord)
        assertEquals("", result.remainingCommand)

        val hindiResult = WakeWordDetector.checkWakeWord("मैक्स")
        assertTrue(hindiResult.hasWakeWord)
        assertTrue(hindiResult.isOnlyWakeWord)
    }

    @Test
    fun testWakeWordWithCommand() {
        val result = WakeWordDetector.checkWakeWord("MAX, YouTube kholo")
        assertTrue(result.hasWakeWord)
        assertFalse(result.isOnlyWakeWord)
        assertEquals("YouTube kholo", result.remainingCommand)
    }

    @Test
    fun testNoWakeWord() {
        val result = WakeWordDetector.checkWakeWord("aaj mausam kaisa hai")
        assertFalse(result.hasWakeWord)
        assertFalse(result.isOnlyWakeWord)
        assertEquals("aaj mausam kaisa hai", result.remainingCommand)
    }
}
