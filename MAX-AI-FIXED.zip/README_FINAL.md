# MAX AI — Final Candidate

This repository is the final-candidate Android source package based on the supplied MAX-AI project.

## Build with GitHub Actions
1. Push/upload the complete repository to GitHub.
2. Add `GEMINI_API_KEY` as a GitHub Actions repository secret if the app's current
   Gemini integration requires it.
3. Open **Actions → Build MAX AI APK → Run workflow**.
4. Download the `MAX-AI-debug-apk` artifact.
5. Install the APK on the Android phone.

## Important
- Android Accessibility permission must be enabled by the user for UI automation.
- The app must not bypass lock screens, OTPs, PINs, passwords, or banking security.
- Some third-party apps can restrict accessibility automation; 100% automation of
  every app is not technically guaranteed.
- The Smart Action Engine uses PLAN/ACT/OBSERVE/VERIFY/RECOVER semantics and is
  designed to connect to the project's existing ToolExecutor and Accessibility
  service.
