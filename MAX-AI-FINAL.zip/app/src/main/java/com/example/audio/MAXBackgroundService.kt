package com.example.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.ai.GeminiAssistantService
import com.example.ai.WakeWordDetector
import com.example.model.ExecutionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class MAXBackgroundService : Service() {

    companion object {

        private const val CHANNEL_ID = "max_ai_voice"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START = "MAX_START"
        const val ACTION_STOP = "MAX_STOP"

        @Volatile
        var isRunning = false
            private set

        @Volatile
        private var instance: MAXBackgroundService? = null

        fun onScreenLocked() {
            instance?.handleScreenLocked()
        }

        fun onScreenUnlocked() {
            instance?.handleScreenUnlocked()
        }
    }

    private val serviceScope =
        CoroutineScope(
            SupervisorJob() + Dispatchers.Main.immediate
        )

    private lateinit var speechManager: SpeechManager
    private lateinit var voiceDetector: AudioActivityDetector
    private lateinit var audioPlayer: MAXAudioPlayer
    private lateinit var geminiService: GeminiAssistantService

    private var active = false
    private var screenLocked = false
    private var isForeground = false

    private var processing = false
    private var commandListening = false

    private var resumeJob: Job? = null
    private var processingJob: Job? = null

    override fun onCreate() {
        super.onCreate()

        instance = this

        createNotificationChannel()

        speechManager =
            SpeechManager(applicationContext)

        voiceDetector =
            AudioActivityDetector(serviceScope)

        audioPlayer =
            MAXAudioPlayer(applicationContext)

        geminiService =
            GeminiAssistantService(applicationContext)

        voiceDetector.onAudioLevel = { level ->

            if (
                active &&
                !screenLocked &&
                !commandListening &&
                !processing
            ) {
                MAXServiceState.setAudioLevel(level)
            }
        }

        voiceDetector.onSpeechStarted = {

            if (
                active &&
                !screenLocked &&
                !processing &&
                !commandListening
            ) {
                startCommandRecognition()
            }
        }

        serviceScope.launch {

            speechManager.micVolume.collect { level ->

                if (
                    active &&
                    !screenLocked &&
                    commandListening
                ) {
                    MAXServiceState.setAudioLevel(level)
                }
            }
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            ACTION_STOP -> {
                stopMaxService()
                return START_NOT_STICKY
            }

            ACTION_START -> {
                startMaxService()
            }

            else -> {
                startMaxService()
            }
        }

        return START_STICKY
    }

    private fun startMaxService() {

        if (!isForeground) {

            val notification =
                buildNotification()

            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
            ) {

                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo
                        .FOREGROUND_SERVICE_TYPE_MICROPHONE
                )

            } else {

                @Suppress("DEPRECATION")
                startForeground(
                    NOTIFICATION_ID,
                    notification
                )
            }

            isForeground = true
        }

        if (active) {
            return
        }

        active = true
        screenLocked = false
        isRunning = true

        processing = false
        commandListening = false

        MAXServiceState.setActive(true)

        MAXServiceState.setState(
            ExecutionState.LISTENING
        )

        MAXServiceState.setHeardText(
            "सुन रही हूँ..."
        )

        MAXServiceState.setActionInfo(null)

        startIdleMonitor()
    }

    /**
     * MAX remains active here.
     *
     * SpeechRecognizer is NOT kept open.
     * A lightweight AudioRecord detector watches
     * for actual speech activity.
     */
    private fun startIdleMonitor() {

        if (
            !active ||
            screenLocked ||
            processing ||
            commandListening
        ) {
            return
        }

        resumeJob?.cancel()
        resumeJob = null

        speechManager.cancel()

        voiceDetector.stop()

        MAXServiceState.setAudioLevel(0f)

        MAXServiceState.setState(
            ExecutionState.LISTENING
        )

        voiceDetector.start()
    }

    /**
     * Only called after the audio detector
     * detects that the user actually started speaking.
     */
    private fun startCommandRecognition() {

        if (
            !active ||
            screenLocked ||
            processing ||
            commandListening
        ) {
            return
        }

        commandListening = true

        voiceDetector.stop()

        MAXServiceState.setAudioLevel(0f)

        MAXServiceState.setState(
            ExecutionState.LISTENING
        )

        speechManager.startContinuousListening(

            onResult = { text ->

                if (
                    !active ||
                    screenLocked ||
                    !commandListening
                ) {
                    return@startContinuousListening
                }

                val command =
                    text.trim()

                commandListening = false

                speechManager.cancel()

                MAXServiceState.setAudioLevel(0f)

                if (command.isBlank()) {

                    resumeIdleMonitor()

                    return@startContinuousListening
                }

                MAXServiceState.setHeardText(
                    command
                )

                processCommand(command)
            },

            onPartial = { partial ->

                if (
                    active &&
                    !screenLocked &&
                    commandListening &&
                    partial.isNotBlank()
                ) {

                    MAXServiceState.setHeardText(
                        partial
                    )
                }
            },

            onError = { message ->

                commandListening = false

                speechManager.cancel()

                MAXServiceState.setAudioLevel(0f)

                if (
                    active &&
                    !screenLocked &&
                    !processing
                ) {

                    MAXServiceState.setResponseText(
                        message
                    )

                    resumeIdleMonitor()
                }
            }
        )
    }

    private fun processCommand(
        rawText: String
    ) {

        if (
            !active ||
            screenLocked ||
            processing
        ) {
            return
        }

        processing = true

        processingJob =
            serviceScope.launch {

                MAXServiceState.setState(
                    ExecutionState.THINKING
                )

                try {

                    val detection =
                        WakeWordDetector
                            .checkWakeWord(rawText)

                    if (detection.isOnlyWakeWord) {

                        speakAndResume(
                            "Yes Boss, बताइए क्या काम है।"
                        )

                        return@launch
                    }

                    val command =
                        if (detection.hasWakeWord) {
                            detection.remainingCommand
                        } else {
                            rawText
                        }

                    if (command.isBlank()) {

                        processing = false

                        resumeIdleMonitor()

                        return@launch
                    }

                    MAXServiceState.setState(
                        ExecutionState.EXECUTING
                    )

                    val result =
                        geminiService.processQuery(
                            command
                        )

                    MAXServiceState.setActionInfo(
                        result.second?.toString()
                    )

                    val response =
                        result.first
                            .trim()
                            .ifBlank {
                                "ठीक है Boss।"
                            }

                    speakAndResume(response)

                } catch (_: Exception) {

                    if (!active || screenLocked) {
                        return@launch
                    }

                    speakAndResume(
                        "Boss, अभी थोड़ा technical issue आ गया।"
                    )
                }
            }
    }

    private fun speakAndResume(
        text: String
    ) {

        if (
            !active ||
            screenLocked
        ) {
            return
        }

        commandListening = false

        voiceDetector.stop()
        speechManager.cancel()

        MAXServiceState.setResponseText(
            text
        )

        MAXServiceState.setState(
            ExecutionState.SPEAKING
        )

        audioPlayer.speak(

            text = text,

            onStart = {

                voiceDetector.stop()
                speechManager.cancel()

                MAXServiceState.setAudioLevel(0f)
            },

            onDone = {

                if (
                    active &&
                    !screenLocked
                ) {

                    processing = false

                    resumeIdleMonitor()
                }
            }
        )
    }

    private fun resumeIdleMonitor() {

        resumeJob?.cancel()

        resumeJob =
            serviceScope.launch {

                delay(250L)

                if (
                    active &&
                    !screenLocked &&
                    !processing &&
                    !commandListening
                ) {
                    startIdleMonitor()
                }
            }
    }

    private fun handleScreenLocked() {

        if (!active) {
            return
        }

        screenLocked = true

        resumeJob?.cancel()
        resumeJob = null

        processingJob?.cancel()
        processingJob = null

        commandListening = false
        processing = false

        voiceDetector.stop()
        speechManager.cancel()
        audioPlayer.stop()

        MAXServiceState.setAudioLevel(0f)

        MAXServiceState.setState(
            ExecutionState.DISCONNECTED
        )
    }

    private fun handleScreenUnlocked() {

        if (!active) {
            return
        }

        screenLocked = false

        MAXServiceState.setState(
            ExecutionState.LISTENING
        )

        MAXServiceState.setHeardText(
            "फिर से सुन रही हूँ..."
        )

        resumeIdleMonitor()
    }

    private fun stopMaxService() {

        active = false
        screenLocked = false
        isRunning = false

        processing = false
        commandListening = false

        resumeJob?.cancel()
        resumeJob = null

        processingJob?.cancel()
        processingJob = null

        voiceDetector.stop()
        speechManager.cancel()
        audioPlayer.stop()

        MAXServiceState.reset()

        stopForegroundCompat()

        isForeground = false

        stopSelf()
    }

    private fun buildNotification(): Notification {

        return NotificationCompat
            .Builder(
                this,
                CHANNEL_ID
            )
            .setSmallIcon(
                R.mipmap.ic_launcher
            )
            .setContentTitle(
                "MAX AI"
            )
            .setContentText(
                "MAX active hai"
            )
            .setOngoing(true)
            .setCategory(
                NotificationCompat.CATEGORY_SERVICE
            )
            .setPriority(
                NotificationCompat.PRIORITY_LOW
            )
            .setShowWhen(false)
            .build()
    }

    private fun createNotificationChannel() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val channel =
                NotificationChannel(
                    CHANNEL_ID,
                    "MAX AI Voice Assistant",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {

                    description =
                        "MAX AI background voice assistant"

                    setShowBadge(false)
                }

            val manager =
                getSystemService(
                    NotificationManager::class.java
                )

            manager.createNotificationChannel(
                channel
            )
        }
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? = null

    override fun onDestroy() {

        active = false
        screenLocked = false
        isRunning = false

        processing = false
        commandListening = false

        resumeJob?.cancel()
        processingJob?.cancel()

        try {
            voiceDetector.destroy()
        } catch (_: Exception) {
        }

        try {
            speechManager.destroy()
        } catch (_: Exception) {
        }

        try {
            audioPlayer.destroy()
        } catch (_: Exception) {
        }

        MAXServiceState.reset()

        instance = null

        serviceScope.cancel()

        stopForegroundCompat()

        super.onDestroy()
    }

    private fun stopForegroundCompat() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.N
        ) {

            stopForeground(
                STOP_FOREGROUND_REMOVE
            )

        } else {

            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }
}
